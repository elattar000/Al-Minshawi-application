# ربط Firebase - نسخة نوادر المنشاوي

تم إدخال ملف `google-services.json` داخل المشروع.

بيانات المشروع المستخدمة:

- Project ID: `nawader-minshawi`
- Android package name: `com.nawader.nawader_minshawi`
- Storage bucket: `nawader-minshawi.firebasestorage.app`

## المطلوب منك داخل Firebase Console

1. افتح Authentication.
2. اضغط Get started.
3. افتح Sign-in method.
4. فعّل Email/Password ثم Save.

## Remote Config للتحديث بدون APK

افتح Remote Config وأضف المفاتيح التالية:

```text
archive_identifier = Encyclopedia-of-Alminshawi
app_maintenance = false
maintenance_message = التطبيق تحت الصيانة حاليًا
featured_message = تلاوات مختارة من نوادر الشيخ محمد صديق المنشاوي
force_update_min_build = 1
```

- تغيير `archive_identifier` يغير مصدر التلاوات من Internet Archive.
- تغيير `app_maintenance` إلى true يفتح شاشة صيانة داخل التطبيق.
- تغيير الرسائل يتم بدون APK جديد.
- تغيير الكود أو إضافة شاشة جديدة يحتاج APK جديد.
