// File generated for Nawader Minshawi Firebase Android configuration.
// Keep google-services.json in android/app when building Android.

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError('Web Firebase options are not configured for this project.');
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      default:
        throw UnsupportedError('Firebase options are currently configured for Android only.');
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDjfF6S-PKZEoLDJRLVwnD_xzXY00GnoZI',
    appId: '1:133259482322:android:fcf252f8b8ae8ca6cf490b',
    messagingSenderId: '133259482322',
    projectId: 'nawader-minshawi',
    storageBucket: 'nawader-minshawi.firebasestorage.app',
    androidClientId: null,
  );
}
