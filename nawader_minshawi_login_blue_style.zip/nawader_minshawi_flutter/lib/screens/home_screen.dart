import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/archive_service.dart';
import 'main_layout.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<dynamic> _allFiles = [];
  bool _isLoading = true;
  String _errorMsg = '';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      final files = await ArchiveService.fetchAudioFiles();
      setState(() {
        _allFiles = files;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMsg = e.toString();
        _isLoading = false;
      });
    }
  }

  void _playAudio(String fileName, String downloadUrl) {
    setState(() {
      currentTrackTitle = fileName.replaceAll('.mp3', '').replaceAll('_', ' ');
    });
    globalAudioPlayer.setUrl('https://archive.org/download/Encyclopedia-of-Alminshawi/$downloadUrl');
    globalAudioPlayer.play();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('نوادر التلاوات'),
        bottom: TabBar(
          controller: _tabController,
          labelColor: const Color(0xFF168BD0),
          unselectedLabelColor: Colors.grey,
          indicatorColor: const Color(0xFF168BD0),
          indicatorWeight: 3,
          tabs: const [
            Tab(text: 'محافل خارجية'),
            Tab(text: 'قرآن مجود'),
            Tab(text: 'قصار السور'),
          ],
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMsg.isNotEmpty
              ? _buildErrorWidget()
              : TabBarView(
                  controller: _tabController,
                  children: [
                    _buildList(_allFiles),
                    _buildList(_allFiles.reversed.toList()),
                    _buildList(_allFiles),
                  ],
                ),
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.wifi_off, size: 80, color: Colors.grey),
          const SizedBox(height: 16),
          Text(_errorMsg, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, color: Colors.red)),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              setState(() { _isLoading = true; _errorMsg = ''; });
              _loadData();
            },
            child: const Text('إعادة المحاولة'),
          )
        ],
      ),
    ).animate().fade();
  }

  Widget _buildList(List files) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: files.length,
      itemBuilder: (context, index) {
        final file = files[index];
        final fileName = file['name'] ?? 'تلاوة غير معروفة';

        return Card(
          elevation: 2,
          margin: const EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: ListTile(
            contentPadding: const EdgeInsets.all(8),
            leading: Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: const Color(0xFFE0F2FE),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.audiotrack, color: Color(0xFF168BD0)),
            ),
            title: Text(
              fileName.replaceAll('.mp3', '').replaceAll('_', ' '),
              maxLines: 2,
              style: GoogleFonts.ibmPlexSansArabic(fontWeight: FontWeight.w700, fontSize: 15),
            ),
            trailing: const Icon(Icons.play_circle_outline, size: 30, color: Colors.grey),
            onTap: () => _playAudio(fileName, file['name']),
          ),
        ).animate().fade(delay: (index < 12 ? 35 * index : 0).ms).slideX(begin: 0.1);
      },
    );
  }
}
