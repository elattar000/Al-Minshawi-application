import 'dart:convert';
import 'package:http/http.dart' as http;

class ArchiveService {
  static Future<List<dynamic>> fetchAudioFiles() async {
    try {
      final url = Uri.parse('https://archive.org/metadata/Encyclopedia-of-Alminshawi');
      final response = await http.get(url).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final files = data['files'] as List;
        return files.where((file) => file['name'].toString().endsWith('.mp3')).toList();
      } else {
        throw Exception('خطأ في الخادم');
      }
    } catch (e) {
      throw Exception('تأكد من اتصالك بالإنترنت. لا يمكن الوصول للسيرفر الآن.');
    }
  }
}
