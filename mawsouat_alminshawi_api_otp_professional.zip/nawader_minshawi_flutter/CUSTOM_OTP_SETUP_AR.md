# إعداد إرسال أكواد عربية بعيدًا عن رسائل Firebase

هذه النسخة لا تعتمد على رسالة تأكيد Firebase الافتراضية. التطبيق يطلب كودًا عربيًا من سيرفر خارجي عبر `OTP_API_BASE_URL`.

## المطلوب قبل البناء
1. ارفع مجلد `backend/otp_server` على Cloud Run أو Render أو أي Node.js hosting.
2. ضع بيانات SMTP في ملف البيئة: `SMTP_HOST`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM`.
3. ضع `OTP_API_KEY` سر طويل.
4. للاستعادة بكلمة المرور العربية ضع `FIREBASE_SERVICE_ACCOUNT_JSON` من Firebase Service Account.
5. في Codemagic أضف Environment Variables:
   - `OTP_API_BASE_URL` مثل: `https://your-otp-server.run.app`
   - `OTP_API_KEY` نفس السر الموجود في السيرفر.

## ملاحظة مهمة
لا تضع بيانات SMTP أو Service Account داخل تطبيق Flutter نهائيًا. وجودها داخل APK يجعلها قابلة للاستخراج.
