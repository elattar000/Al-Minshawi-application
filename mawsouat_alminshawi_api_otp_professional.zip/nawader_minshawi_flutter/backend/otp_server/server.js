import 'dotenv/config';
import crypto from 'node:crypto';
import express from 'express';
import cors from 'cors';
import nodemailer from 'nodemailer';
import admin from 'firebase-admin';

const app = express();
const port = Number(process.env.PORT || 8080);
const ttlMinutes = Number(process.env.OTP_TTL_MINUTES || 10);
const appName = process.env.APP_NAME || 'موسوعة الشيخ المنشاوي';
const allowedOrigin = process.env.ALLOWED_ORIGIN || '*';
const apiKey = process.env.OTP_API_KEY || '';

app.use(cors({ origin: allowedOrigin }));
app.use(express.json({ limit: '24kb' }));

if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON && !admin.apps.length) {
  const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
  admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
}

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 465),
  secure: String(process.env.SMTP_SECURE || 'true') === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

const store = new Map();
const lastSendByEmail = new Map();

function requireApiKey(req, res, next) {
  if (!apiKey) return next();
  if (req.header('x-api-key') !== apiKey) {
    return res.status(401).json({ ok: false, message_ar: 'غير مصرح باستخدام خدمة الأكواد' });
  }
  next();
}

app.use(requireApiKey);

function normalizeEmail(email) {
  return String(email || '').trim().toLowerCase();
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function hashCode(code, salt) {
  return crypto.createHash('sha256').update(`${salt}:${code}`).digest('hex');
}

function makeCode() {
  return String(crypto.randomInt(100000, 1000000));
}

function canSend(email) {
  const now = Date.now();
  const last = lastSendByEmail.get(email) || 0;
  if (now - last < 60 * 1000) return false;
  lastSendByEmail.set(email, now);
  return true;
}

async function sendArabicMail({ to, subject, title, body, actionText, actionUrl, code }) {
  const codeBlock = code
    ? `<div style="font-size:34px;font-weight:800;letter-spacing:7px;background:#eef7ff;color:#0f5e9c;padding:16px 20px;border-radius:16px;display:inline-block;margin:12px 0">${code}</div>`
    : '';
  const actionButton = actionText && actionUrl
    ? `<a href="${actionUrl}" style="display:inline-block;background:#168BD0;color:#fff;text-decoration:none;padding:14px 22px;border-radius:14px;font-weight:800;margin-top:14px">${actionText}</a>`
    : '';
  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to,
    subject,
    text: code ? `${title}\n${body}\nالكود: ${code}` : `${title}\n${body}\n${actionUrl || ''}`,
    html: `
      <div dir="rtl" style="font-family:Tahoma,Arial,sans-serif;background:#f7fbff;padding:28px;color:#1f2937">
        <div style="max-width:520px;margin:auto;background:white;border-radius:22px;padding:26px;box-shadow:0 12px 30px rgba(22,139,208,.10)">
          <h2 style="color:#168BD0;margin:0 0 12px;font-size:26px">${title}</h2>
          <p style="font-size:17px;line-height:1.9;margin:0 0 10px">${body}</p>
          ${codeBlock}
          ${actionButton}
          <p style="font-size:13px;color:#64748b;margin-top:22px">هذه رسالة تلقائية من ${appName}. لا تشارك الكود مع أي شخص.</p>
        </div>
      </div>
    `,
  });
}

app.get('/health', (req, res) => {
  res.json({ ok: true, service: 'mawsouat-alminshawi-otp' });
});

app.post('/send', async (req, res) => {
  const email = normalizeEmail(req.body?.email);
  if (!isValidEmail(email)) {
    return res.status(400).json({ ok: false, message_ar: 'صيغة البريد الإلكتروني غير صحيحة' });
  }
  if (!canSend(email)) {
    return res.status(429).json({ ok: false, message_ar: 'انتظر دقيقة قبل طلب كود جديد' });
  }

  const requestId = crypto.randomUUID();
  const salt = crypto.randomBytes(16).toString('hex');
  const code = makeCode();
  const expiresAt = Date.now() + ttlMinutes * 60 * 1000;
  store.set(requestId, {
    email,
    salt,
    codeHash: hashCode(code, salt),
    expiresAt,
    attempts: 0,
  });

  await sendArabicMail({
    to: email,
    subject: `كود تأكيد حسابك في ${appName}`,
    title: appName,
    body: `استخدم هذا الكود لتأكيد بريدك الإلكتروني. ينتهي الكود خلال ${ttlMinutes} دقائق.`,
    code,
  });

  return res.json({ ok: true, requestId, expiresInMinutes: ttlMinutes });
});

app.post('/verify', (req, res) => {
  const email = normalizeEmail(req.body?.email);
  const requestId = String(req.body?.requestId || '');
  const code = String(req.body?.code || '').trim();
  const row = store.get(requestId);

  if (!row || row.email !== email || Date.now() > row.expiresAt) {
    return res.status(400).json({ ok: false, message_ar: 'الكود غير صحيح أو انتهت صلاحيته' });
  }

  row.attempts += 1;
  if (row.attempts > 5) {
    store.delete(requestId);
    return res.status(429).json({ ok: false, message_ar: 'تم تجاوز عدد المحاولات المسموح' });
  }

  const ok = hashCode(code, row.salt) === row.codeHash;
  if (ok) store.delete(requestId);
  return res.json({ ok });
});

app.post('/password-reset', async (req, res) => {
  const email = normalizeEmail(req.body?.email);
  if (!isValidEmail(email)) {
    return res.status(400).json({ ok: false, message_ar: 'صيغة البريد الإلكتروني غير صحيحة' });
  }
  if (!admin.apps.length) {
    return res.status(500).json({ ok: false, message_ar: 'خدمة استعادة كلمة المرور غير مفعلة على السيرفر' });
  }
  try {
    const resetLink = await admin.auth().generatePasswordResetLink(email, {
      url: process.env.RESET_CONTINUE_URL || 'https://example.com',
      handleCodeInApp: false,
    });
    await sendArabicMail({
      to: email,
      subject: `استعادة كلمة المرور - ${appName}`,
      title: 'استعادة كلمة المرور',
      body: 'اضغط على الزر التالي لتعيين كلمة مرور جديدة لحسابك.',
      actionText: 'إعادة تعيين كلمة المرور',
      actionUrl: resetLink,
    });
    return res.json({ ok: true });
  } catch (e) {
    return res.status(400).json({ ok: false, message_ar: 'لا يوجد حساب بهذا البريد أو تعذر إرسال الرسالة' });
  }
});

setInterval(() => {
  const now = Date.now();
  for (const [key, row] of store.entries()) {
    if (now > row.expiresAt) store.delete(key);
  }
}, 60 * 1000).unref();

app.listen(port, () => {
  console.log(`OTP server listening on http://localhost:${port}`);
});
