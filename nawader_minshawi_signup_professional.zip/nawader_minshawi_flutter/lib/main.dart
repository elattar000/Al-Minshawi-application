import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:url_launcher/url_launcher.dart';
import 'firebase_options.dart';

// ==========================================
// إدارة حالة المشغل والتنقل بين التلاوات
// ==========================================
final AudioPlayer globalAudioPlayer = AudioPlayer();

String archiveAudioUrl(String fileName) {
  return Uri.https(
    'archive.org',
    '/download/Encyclopedia-of-Alminshawi/$fileName',
  ).toString();
}

class PlaybackState {
  final String title;
  final String fileName;
  final List<Map<String, dynamic>> playlist;
  final int currentIndex;

  PlaybackState({
    required this.title,
    required this.fileName,
    required this.playlist,
    required this.currentIndex,
  });
}

final ValueNotifier<PlaybackState?> currentPlayback = ValueNotifier(null);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MinshawiApp());
}

class MinshawiApp extends StatelessWidget {
  const MinshawiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'نوادر المنشاوي',
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('ar', 'AE'),
      ],
      locale: const Locale('ar', 'AE'),
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
        primaryColor: const Color(0xFF00A9B0),
        textTheme: GoogleFonts.ibmPlexSansArabicTextTheme(),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.white,
          elevation: 0,
          scrolledUnderElevation: 0,
          iconTheme: const IconThemeData(color: Color(0xFF1E293B)),
          titleTextStyle: GoogleFonts.ibmPlexSansArabic(
            color: const Color(0xFF1E293B),
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

// ==========================================
// 1. شاشة اللودنج (Splash Screen)
// ==========================================
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      final user = FirebaseAuth.instance.currentUser;
      if (!mounted) return;
      if (user != null) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainLayout()));
      } else {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/images/app_logo.jpg', width: 150)
                .animate()
                .scale(duration: 800.ms, curve: Curves.easeOutBack),
            const SizedBox(height: 24),
            const CircularProgressIndicator(color: Color(0xFF00A9B0))
                .animate()
                .fadeIn(delay: 500.ms),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 2. شاشة تسجيل الدخول + إنشاء حساب
// ==========================================
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (_emailController.text.trim().isEmpty || _passwordController.text.trim().isEmpty) {
      _showMessage('اكتب البريد الإلكتروني وكلمة المرور');
      return;
    }
    setState(() => _isLoading = true);
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainLayout()));
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      _showMessage(_authMessage(e));
      setState(() => _isLoading = false);
    } catch (_) {
      if (!mounted) return;
      _showMessage('حدث خطأ غير متوقع');
      setState(() => _isLoading = false);
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: GoogleFonts.ibmPlexSansArabic()),
        backgroundColor: Colors.red,
      ),
    );
  }

  String _authMessage(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'بيانات الدخول غير صحيحة';
      case 'invalid-email':
        return 'البريد الإلكتروني غير صحيح';
      case 'too-many-requests':
        return 'محاولات كثيرة. حاول لاحقًا';
      case 'operation-not-allowed':
        return 'فعّل Email/Password من Firebase Authentication';
      default:
        return e.message ?? 'خطأ في تسجيل الدخول';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: Image.asset('assets/images/app_logo.jpg', width: 124)
                      .animate()
                      .slideY(begin: -0.2)
                      .fadeIn(),
                ),
                const SizedBox(height: 30),
                Text(
                  'سجل دخول',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.ibmPlexSansArabic(
                    fontSize: 38,
                    fontWeight: FontWeight.w800,
                    color: const Color(0xFF00A9B0),
                  ),
                ).animate().fadeIn(delay: 200.ms),
                const SizedBox(height: 6),
                Text(
                  'ادخل إلى حسابك واستمع لنوادر التلاوات',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.ibmPlexSansArabic(fontSize: 17, color: const Color(0xFF475569)),
                ).animate().fadeIn(delay: 300.ms),
                const SizedBox(height: 38),
                TextField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  decoration: _buildInputDecoration('البريد الإلكتروني', Icons.email_outlined),
                ).animate().slideX(begin: 0.1, delay: 400.ms).fadeIn(),
                const SizedBox(height: 16),
                TextField(
                  controller: _passwordController,
                  obscureText: true,
                  textInputAction: TextInputAction.done,
                  onSubmitted: (_) => _login(),
                  decoration: _buildInputDecoration('كلمة المرور', Icons.lock_outline),
                ).animate().slideX(begin: 0.1, delay: 500.ms).fadeIn(),
                const SizedBox(height: 32),
                SizedBox(
                  height: 58,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF00A9B0),
                      elevation: 10,
                      shadowColor: const Color(0xFF00A9B0).withOpacity(0.25),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    onPressed: _isLoading ? null : _login,
                    child: _isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text(
                            'تسجيل الدخول',
                            style: GoogleFonts.ibmPlexSansArabic(
                              fontSize: 19,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                            ),
                          ),
                  ),
                ).animate().scale(delay: 600.ms),
                const SizedBox(height: 26),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'ليس لديك حساب؟',
                      style: GoogleFonts.ibmPlexSansArabic(fontSize: 16, color: const Color(0xFF334155)),
                    ),
                    TextButton(
                      onPressed: _isLoading
                          ? null
                          : () => Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => const RegisterScreen()),
                              ),
                      child: Text(
                        'سجل الآن',
                        style: GoogleFonts.ibmPlexSansArabic(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: const Color(0xFF00A9B0),
                        ),
                      ),
                    ),
                  ],
                ).animate().fadeIn(delay: 700.ms),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  bool _isLoading = false;
  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  Future<void> _createAccount() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();
    final confirmPassword = _confirmPasswordController.text.trim();

    if (email.isEmpty || password.isEmpty || confirmPassword.isEmpty) {
      _showMessage('اكتب البريد الإلكتروني وكلمة المرور');
      return;
    }
    if (password.length < 6) {
      _showMessage('كلمة المرور يجب ألا تقل عن 6 أحرف');
      return;
    }
    if (password != confirmPassword) {
      _showMessage('تأكيد كلمة المرور غير مطابق');
      return;
    }

    setState(() => _isLoading = true);
    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const MainLayout()),
        (route) => false,
      );
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      _showMessage(_authMessage(e));
      setState(() => _isLoading = false);
    } catch (_) {
      if (!mounted) return;
      _showMessage('حدث خطأ غير متوقع');
      setState(() => _isLoading = false);
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: GoogleFonts.ibmPlexSansArabic()),
        backgroundColor: Colors.red,
      ),
    );
  }

  String _authMessage(FirebaseAuthException e) {
    switch (e.code) {
      case 'email-already-in-use':
        return 'هذا البريد مسجل بالفعل';
      case 'invalid-email':
        return 'البريد الإلكتروني غير صحيح';
      case 'weak-password':
        return 'كلمة المرور ضعيفة';
      case 'operation-not-allowed':
        return 'فعّل Email/Password من Firebase Authentication';
      case 'network-request-failed':
        return 'تأكد من اتصال الإنترنت';
      default:
        return e.message ?? 'تعذر إنشاء الحساب';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Align(
                  alignment: AlignmentDirectional.topStart,
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Color(0xFF00A9B0)),
                    onPressed: _isLoading ? null : () => Navigator.pop(context),
                  ),
                ),
                Center(
                  child: Image.asset('assets/images/app_logo.jpg', width: 128)
                      .animate()
                      .scale(duration: 650.ms, curve: Curves.easeOutBack),
                ),
                const SizedBox(height: 26),
                Text(
                  'اعمل حساب',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.ibmPlexSansArabic(
                    fontSize: 40,
                    fontWeight: FontWeight.w800,
                    color: const Color(0xFF00A9B0),
                  ),
                ).animate().fadeIn(delay: 150.ms).slideY(begin: 0.12),
                const SizedBox(height: 6),
                Text(
                  'أنشئ حسابك الجديد وابدأ الاستماع',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.ibmPlexSansArabic(fontSize: 17, color: const Color(0xFF475569)),
                ).animate().fadeIn(delay: 250.ms),
                const SizedBox(height: 38),
                TextField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  decoration: _buildInputDecoration('البريد الإلكتروني', Icons.email_outlined),
                ).animate().fadeIn(delay: 350.ms).slideX(begin: 0.1),
                const SizedBox(height: 16),
                TextField(
                  controller: _passwordController,
                  obscureText: _obscurePassword,
                  textInputAction: TextInputAction.next,
                  decoration: _buildInputDecoration(
                    'كلمة المرور',
                    Icons.lock_outline,
                    suffix: IconButton(
                      onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                      icon: Icon(
                        _obscurePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ).animate().fadeIn(delay: 450.ms).slideX(begin: 0.1),
                const SizedBox(height: 16),
                TextField(
                  controller: _confirmPasswordController,
                  obscureText: _obscureConfirmPassword,
                  textInputAction: TextInputAction.done,
                  onSubmitted: (_) => _createAccount(),
                  decoration: _buildInputDecoration(
                    'تأكيد كلمة المرور',
                    Icons.verified_user_outlined,
                    suffix: IconButton(
                      onPressed: () => setState(() => _obscureConfirmPassword = !_obscureConfirmPassword),
                      icon: Icon(
                        _obscureConfirmPassword ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ).animate().fadeIn(delay: 550.ms).slideX(begin: 0.1),
                const SizedBox(height: 32),
                SizedBox(
                  height: 58,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF00A9B0),
                      elevation: 10,
                      shadowColor: const Color(0xFF00A9B0).withOpacity(0.25),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    onPressed: _isLoading ? null : _createAccount,
                    child: _isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text(
                            'اعمل حساب',
                            style: GoogleFonts.ibmPlexSansArabic(
                              fontSize: 19,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                            ),
                          ),
                  ),
                ).animate().scale(delay: 650.ms),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'لديك حساب بالفعل؟',
                      style: GoogleFonts.ibmPlexSansArabic(fontSize: 16, color: const Color(0xFF334155)),
                    ),
                    TextButton(
                      onPressed: _isLoading ? null : () => Navigator.pop(context),
                      child: Text(
                        'سجل دخول الآن',
                        style: GoogleFonts.ibmPlexSansArabic(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: const Color(0xFF00A9B0),
                        ),
                      ),
                    ),
                  ],
                ).animate().fadeIn(delay: 750.ms),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

InputDecoration _buildInputDecoration(String hint, IconData icon, {Widget? suffix}) {
  return InputDecoration(
    hintText: hint,
    hintStyle: GoogleFonts.ibmPlexSansArabic(color: Colors.grey[500], fontSize: 17),
    prefixIcon: Icon(icon, color: Colors.grey),
    suffixIcon: suffix,
    filled: true,
    fillColor: Colors.white,
    contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: Colors.grey.shade200, width: 1.5),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: Colors.grey.shade200, width: 1.5),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: const BorderSide(color: Color(0xFF00A9B0), width: 1.6),
    ),
  );
}

// ==========================================
// 3. الهيكل الرئيسي (شريط التنقل والمشغل الصغير)
// ==========================================
class MainLayout extends StatefulWidget {
  const MainLayout({super.key});

  @override
  State<MainLayout> createState() => _MainLayoutState();
}

class _MainLayoutState extends State<MainLayout> {
  int _currentIndex = 0;
  final List<Widget> _pages = [
    const HomeScreen(),
    const ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          _pages[_currentIndex],
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: _buildPersistentPlayer(),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        selectedItemColor: const Color(0xFF00A9B0),
        unselectedItemColor: Colors.grey,
        selectedLabelStyle: GoogleFonts.ibmPlexSansArabic(fontWeight: FontWeight.bold),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_filled), label: 'الرئيسية'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }

  Widget _buildPersistentPlayer() {
    return ValueListenableBuilder<PlaybackState?>(
      valueListenable: currentPlayback,
      builder: (context, playback, child) {
        if (playback == null) return const SizedBox.shrink();

        return GestureDetector(
          onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const DetailedPlayerScreen()));
          },
          child: Container(
            margin: const EdgeInsets.only(left: 12, right: 12, bottom: 8, top: 4),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFF1E293B),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 10, offset: const Offset(0, 4)),
              ],
            ),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.asset('assets/images/sheikh_logo.jpg', width: 48, height: 48, fit: BoxFit.cover),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        playback.title,
                        style: GoogleFonts.ibmPlexSansArabic(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          color: Colors.white,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        'الشيخ محمد صديق المنشاوي',
                        style: GoogleFonts.ibmPlexSansArabic(color: Colors.grey[400], fontSize: 12),
                      ),
                    ],
                  ),
                ),
                StreamBuilder<PlayerState>(
                  stream: globalAudioPlayer.playerStateStream,
                  builder: (context, snapshot) {
                    final playing = snapshot.data?.playing ?? false;
                    final processingState = snapshot.data?.processingState;

                    if (processingState == ProcessingState.loading || processingState == ProcessingState.buffering) {
                      return const Padding(
                        padding: EdgeInsets.all(8),
                        child: SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                        ),
                      );
                    }
                    return IconButton(
                      icon: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_fill),
                      iconSize: 45,
                      color: Colors.white,
                      onPressed: () => playing ? globalAudioPlayer.pause() : globalAudioPlayer.play(),
                    );
                  },
                ),
              ],
            ),
          ),
        ).animate().slideY(begin: 1.0, duration: 300.ms);
      },
    );
  }
}

// ==========================================
// 4. الشاشة الرئيسية (أقسام بكروت فخمة)
// ==========================================
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, List<Map<String, dynamic>>> _folders = {};
  bool _isLoading = true;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  Future<void> _fetchData() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });
    try {
      final url = Uri.parse('https://archive.org/metadata/Encyclopedia-of-Alminshawi');
      final response = await http.get(url).timeout(const Duration(seconds: 15));
      if (response.statusCode != 200) {
        throw Exception('تعذر الاتصال بالأرشيف');
      }
      final files = json.decode(response.body)['files'] as List;
      final Map<String, List<Map<String, dynamic>>> tempFolders = {};
      for (final rawFile in files) {
        final file = Map<String, dynamic>.from(rawFile as Map);
        final fileName = (file['name'] ?? '').toString();
        if (fileName.toLowerCase().endsWith('.mp3')) {
          final folderName = fileName.contains('/')
              ? fileName.split('/')[0]
              : (fileName.contains('-') ? fileName.split('-')[0] : 'تلاوات أخرى');
          tempFolders.putIfAbsent(folderName, () => []).add(file);
        }
      }
      if (!mounted) return;
      setState(() {
        _folders = tempFolders;
        _isLoading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _errorMessage = 'تعذر تحميل التلاوات. تأكد من اتصال الإنترنت ثم حاول مرة أخرى.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(
          children: [
            const SizedBox(width: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset('assets/images/app_logo.jpg', width: 40, height: 40),
            ),
            const SizedBox(width: 12),
            Text(
              'نوادر المنشاوي',
              style: GoogleFonts.ibmPlexSansArabic(
                fontWeight: FontWeight.bold,
                color: const Color(0xFF00A9B0),
              ),
            ),
          ],
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFF00A9B0)))
          : _errorMessage.isNotEmpty
              ? _buildErrorWidget()
              : ListView.builder(
                  padding: const EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 100),
                  itemCount: _folders.keys.length,
                  itemBuilder: (context, index) {
                    final folderName = _folders.keys.elementAt(index);
                    final count = _folders[folderName]!.length;

                    return GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => TracksScreen(folderName: folderName, tracks: _folders[folderName]!),
                        ),
                      ),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 16),
                        height: 100,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4)),
                          ],
                        ),
                        child: Row(
                          children: [
                            ClipRRect(
                              borderRadius: const BorderRadius.only(
                                topRight: Radius.circular(16),
                                bottomRight: Radius.circular(16),
                              ),
                              child: Image.asset('assets/images/sheikh_logo.jpg', width: 100, height: 100, fit: BoxFit.cover),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    folderName,
                                    style: GoogleFonts.ibmPlexSansArabic(fontSize: 16, fontWeight: FontWeight.bold),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    '$count تلاوة خاشعة',
                                    style: GoogleFonts.ibmPlexSansArabic(
                                      color: const Color(0xFF00A9B0),
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Padding(
                              padding: EdgeInsets.all(16.0),
                              child: Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
                            ),
                          ],
                        ),
                      ).animate().fade(delay: (50 * index).ms).slideX(begin: 0.1),
                    );
                  },
                ),
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.wifi_off_rounded, size: 70, color: Colors.grey),
            const SizedBox(height: 16),
            Text(
              _errorMessage,
              textAlign: TextAlign.center,
              style: GoogleFonts.ibmPlexSansArabic(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: _fetchData, child: const Text('إعادة المحاولة')),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 5. قائمة التلاوات داخل القسم
// ==========================================
class TracksScreen extends StatelessWidget {
  final String folderName;
  final List<Map<String, dynamic>> tracks;

  const TracksScreen({super.key, required this.folderName, required this.tracks});

  Future<void> _playTrack(BuildContext context, int index) async {
    final track = tracks[index];
    final fileName = track['name'].toString();
    final cleanName = fileName.split('/').last.replaceAll('.mp3', '').replaceAll('-', ' ');

    currentPlayback.value = PlaybackState(
      title: cleanName,
      fileName: fileName,
      playlist: tracks,
      currentIndex: index,
    );

    Navigator.push(context, MaterialPageRoute(builder: (_) => const DetailedPlayerScreen()));

    await globalAudioPlayer.setUrl(archiveAudioUrl(fileName));
    globalAudioPlayer.play();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(folderName, style: const TextStyle(fontSize: 18))),
      body: ListView.builder(
        padding: const EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 100),
        itemCount: tracks.length,
        itemBuilder: (context, index) {
          final fileName = tracks[index]['name'].toString();
          final cleanName = fileName.split('/').last.replaceAll('.mp3', '');

          return ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: const Color(0xFFF0F9FA), borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.play_arrow_rounded, color: Color(0xFF00A9B0)),
            ),
            title: Text(cleanName, style: GoogleFonts.ibmPlexSansArabic(fontWeight: FontWeight.bold, fontSize: 14)),
            onTap: () => _playTrack(context, index),
          ).animate().fade();
        },
      ),
    );
  }
}

// ==========================================
// 6. صفحة المشغل المستقلة والفخمة (Detailed Player)
// ==========================================
class DetailedPlayerScreen extends StatelessWidget {
  const DetailedPlayerScreen({super.key});

  void _playNext() {
    final state = currentPlayback.value;
    if (state == null) return;
    final nextIndex = state.currentIndex + 1;
    if (nextIndex < state.playlist.length) {
      _playFromPlaylist(state.playlist, nextIndex);
    }
  }

  void _playPrevious() {
    final state = currentPlayback.value;
    if (state == null) return;
    final prevIndex = state.currentIndex - 1;
    if (prevIndex >= 0) {
      _playFromPlaylist(state.playlist, prevIndex);
    }
  }

  Future<void> _playFromPlaylist(List<Map<String, dynamic>> playlist, int index) async {
    final track = playlist[index];
    final fileName = track['name'].toString();
    final cleanName = fileName.split('/').last.replaceAll('.mp3', '').replaceAll('-', ' ');

    currentPlayback.value = PlaybackState(
      title: cleanName,
      fileName: fileName,
      playlist: playlist,
      currentIndex: index,
    );

    await globalAudioPlayer.setUrl(archiveAudioUrl(fileName));
    globalAudioPlayer.play();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PlaybackState?>(
      valueListenable: currentPlayback,
      builder: (context, playback, child) {
        if (playback == null) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }

        return Scaffold(
          backgroundColor: const Color(0xFF0F172A),
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: IconButton(
              icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white, size: 36),
              onPressed: () => Navigator.pop(context),
            ),
            title: Text('جاري التشغيل الآن', style: GoogleFonts.ibmPlexSansArabic(color: Colors.white, fontSize: 16)),
          ),
          body: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),
              Center(
                child: Container(
                  width: 260,
                  height: 260,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF00A9B0).withOpacity(0.3),
                        blurRadius: 40,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset('assets/images/sheikh_logo.jpg', fit: BoxFit.cover),
                  ),
                ),
              ).animate().scale(duration: 600.ms, curve: Curves.easeOut),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Text(
                  playback.title,
                  textAlign: TextAlign.center,
                  style: GoogleFonts.ibmPlexSansArabic(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'فضيلة الشيخ محمد صديق المنشاوي',
                style: GoogleFonts.ibmPlexSansArabic(fontSize: 15, color: Colors.grey[400]),
              ),
              const Spacer(),
              const AudioProgressBar(),
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.skip_previous_rounded, size: 45, color: Colors.white),
                      onPressed: playback.currentIndex > 0 ? _playPrevious : null,
                    ),
                    StreamBuilder<PlayerState>(
                      stream: globalAudioPlayer.playerStateStream,
                      builder: (context, snapshot) {
                        final playing = snapshot.data?.playing ?? false;
                        final processingState = snapshot.data?.processingState;

                        if (processingState == ProcessingState.loading || processingState == ProcessingState.buffering) {
                          return const SizedBox(
                            width: 80,
                            height: 80,
                            child: Padding(
                              padding: EdgeInsets.all(16),
                              child: CircularProgressIndicator(color: Color(0xFF00A9B0)),
                            ),
                          );
                        }
                        return IconButton(
                          icon: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_fill),
                          iconSize: 85,
                          color: const Color(0xFF00A9B0),
                          onPressed: () => playing ? globalAudioPlayer.pause() : globalAudioPlayer.play(),
                        );
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.skip_next_rounded, size: 45, color: Colors.white),
                      onPressed: playback.currentIndex < playback.playlist.length - 1 ? _playNext : null,
                    ),
                  ],
                ),
              ),
              const Spacer(),
            ],
          ),
        );
      },
    );
  }
}

// ==========================================
// 7. الودجت المخصصة لشريط تقدم التلاوة (Seek Bar)
// ==========================================
class AudioProgressBar extends StatelessWidget {
  const AudioProgressBar({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Duration>(
      stream: globalAudioPlayer.positionStream,
      builder: (context, snapshot) {
        final position = snapshot.data ?? Duration.zero;
        final duration = globalAudioPlayer.duration ?? Duration.zero;

        return Column(
          children: [
            SliderTheme(
              data: SliderTheme.of(context).copyWith(
                activeTrackColor: const Color(0xFF00A9B0),
                inactiveTrackColor: Colors.grey[700],
                thumbColor: Colors.white,
                trackHeight: 4,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
              ),
              child: Slider(
                min: 0.0,
                max: duration.inMilliseconds.toDouble() > 0.0 ? duration.inMilliseconds.toDouble() : 1.0,
                value: position.inMilliseconds.toDouble().clamp(
                      0.0,
                      duration.inMilliseconds.toDouble() > 0.0 ? duration.inMilliseconds.toDouble() : 1.0,
                    ),
                onChanged: (value) {
                  globalAudioPlayer.seek(Duration(milliseconds: value.toInt()));
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(_formatDuration(position), style: const TextStyle(color: Colors.grey, fontSize: 13)),
                  Text(_formatDuration(duration), style: const TextStyle(color: Colors.grey, fontSize: 13)),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  String _formatDuration(Duration d) {
    final minutes = d.inMinutes.toString().padLeft(2, '0');
    final seconds = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }
}

// ==========================================
// 8. شاشة حسابي
// ==========================================
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const CircleAvatar(
            radius: 50,
            backgroundColor: Color(0xFF00A9B0),
            child: Icon(Icons.person, size: 50, color: Colors.white),
          ),
          const SizedBox(height: 16),
          Text(
            user?.email ?? '',
            textAlign: TextAlign.center,
            style: GoogleFonts.ibmPlexSansArabic(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 40),
          _buildItem(Icons.support_agent, 'تواصل معنا', () async {
            final uri = Uri(scheme: 'mailto', path: 'support@example.com');
            if (await canLaunchUrl(uri)) await launchUrl(uri);
          }),
          _buildItem(Icons.logout, 'تسجيل خروج', () async {
            await FirebaseAuth.instance.signOut();
            globalAudioPlayer.stop();
            currentPlayback.value = null;
            if (context.mounted) {
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
            }
          }, isRed: true),
        ],
      ),
    );
  }

  Widget _buildItem(IconData icon, String title, VoidCallback onTap, {bool isRed = false}) {
    return ListTile(
      onTap: onTap,
      leading: Icon(icon, color: isRed ? Colors.red : const Color(0xFF00A9B0)),
      title: Text(
        title,
        style: GoogleFonts.ibmPlexSansArabic(
          fontWeight: FontWeight.bold,
          color: isRed ? Colors.red : Colors.black,
        ),
      ),
    );
  }
}
