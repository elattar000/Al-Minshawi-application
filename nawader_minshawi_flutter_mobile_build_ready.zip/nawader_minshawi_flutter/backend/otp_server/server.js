import 'dotenv/config';
import crypto from 'node:crypto';
import express from 'express';
import cors from 'cors';
import nodemailer from 'nodemailer';

const app = express();
const port = Number(process.env.PORT || 8080);
const ttlMinutes = Number(process.env.OTP_TTL_MINUTES || 10);
const appName = process.env.APP_NAME || 'نوادر المنشاوي';
const allowedOrigin = process.env.ALLOWED_ORIGIN || '*';

app.use(cors({ origin: allowedOrigin }));
app.use(express.json({ limit: '24kb' }));

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 465),
  secure: String(process.env.SMTP_SECURE || 'true') === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

const store = new Map();

function normalizeEmail(email) {
  return String(email || '').trim().toLowerCase();
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function hashCode(code, salt) {
  return crypto.createHash('sha256').update(`${salt}:${code}`).digest('hex');
}

function makeCode() {
  return String(crypto.randomInt(100000, 1000000));
}

app.get('/health', (req, res) => {
  res.json({ ok: true, service: 'nawader-otp-server' });
});

app.post('/send', async (req, res) => {
  const email = normalizeEmail(req.body?.email);
  if (!isValidEmail(email)) {
    return res.status(400).json({ ok: false, message: 'Invalid email' });
  }

  const requestId = crypto.randomUUID();
  const salt = crypto.randomBytes(16).toString('hex');
  const code = makeCode();
  const expiresAt = Date.now() + ttlMinutes * 60 * 1000;
  store.set(requestId, {
    email,
    salt,
    codeHash: hashCode(code, salt),
    expiresAt,
    attempts: 0,
  });

  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: email,
    subject: `كود الدخول إلى ${appName}`,
    text: `كود التحقق الخاص بك هو: ${code}\nينتهي خلال ${ttlMinutes} دقائق.`,
    html: `
      <div dir="rtl" style="font-family:Arial,sans-serif;line-height:1.8;color:#1f2937">
        <h2>${appName}</h2>
        <p>كود التحقق الخاص بك:</p>
        <div style="font-size:32px;font-weight:700;letter-spacing:6px;background:#f1f5f9;padding:14px 18px;border-radius:12px;display:inline-block">${code}</div>
        <p>ينتهي خلال ${ttlMinutes} دقائق.</p>
      </div>
    `,
  });

  return res.json({ ok: true, requestId, expiresInMinutes: ttlMinutes });
});

app.post('/verify', (req, res) => {
  const email = normalizeEmail(req.body?.email);
  const requestId = String(req.body?.requestId || '');
  const code = String(req.body?.code || '').trim();
  const row = store.get(requestId);

  if (!row || row.email !== email || Date.now() > row.expiresAt) {
    return res.status(400).json({ ok: false });
  }

  row.attempts += 1;
  if (row.attempts > 5) {
    store.delete(requestId);
    return res.status(429).json({ ok: false });
  }

  const ok = hashCode(code, row.salt) === row.codeHash;
  if (ok) store.delete(requestId);
  return res.json({ ok });
});

setInterval(() => {
  const now = Date.now();
  for (const [key, row] of store.entries()) {
    if (now > row.expiresAt) store.delete(key);
  }
}, 60 * 1000).unref();

app.listen(port, () => {
  console.log(`OTP server listening on http://localhost:${port}`);
});
