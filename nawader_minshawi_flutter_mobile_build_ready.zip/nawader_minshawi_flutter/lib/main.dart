import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';

const Color kBrand = Color(0xFF42A5F5);
const Color kAccent = Color(0xFF18B8C7);
const Color kInk = Color(0xFF1F2937);
const Color kSoftBg = Color(0xFFF3F7FB);
const String kArchiveIdentifier = 'Encyclopedia-of-Alminshawi';
const String kArchiveFolder = '04-تلاوات الحفلات/';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NawaderApp());
}

class NawaderApp extends StatefulWidget {
  const NawaderApp({super.key});

  @override
  State<NawaderApp> createState() => _NawaderAppState();
}

class _NawaderAppState extends State<NawaderApp> {
  bool _booting = true;
  ThemeMode _themeMode = ThemeMode.light;
  String? _email;

  @override
  void initState() {
    super.initState();
    _loadState();
  }

  Future<void> _loadState() async {
    final prefs = await SharedPreferences.getInstance();
    final dark = prefs.getBool('darkMode') ?? false;
    final email = prefs.getString('email');
    await Future<void>.delayed(const Duration(milliseconds: 1300));
    if (!mounted) return;
    setState(() {
      _themeMode = dark ? ThemeMode.dark : ThemeMode.light;
      _email = email;
      _booting = false;
    });
  }

  Future<void> _setThemeMode(ThemeMode mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('darkMode', mode == ThemeMode.dark);
    if (!mounted) return;
    setState(() => _themeMode = mode);
  }

  Future<void> _onLoggedIn(String email) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('email', email);
    if (!mounted) return;
    setState(() => _email = email);
  }

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('email');
    if (!mounted) return;
    setState(() => _email = null);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'نوادر المنشاوي',
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      themeMode: _themeMode,
      theme: _buildLightTheme(),
      darkTheme: _buildDarkTheme(),
      home: _booting
          ? const SplashScreen()
          : (_email == null
              ? AuthFlow(onSuccess: _onLoggedIn)
              : MainShell(
                  email: _email!,
                  themeMode: _themeMode,
                  onThemeChanged: _setThemeMode,
                  onLogout: _logout,
                )),
    );
  }
}

ThemeData _buildLightTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: kBrand,
    brightness: Brightness.light,
    primary: kBrand,
    secondary: kAccent,
    surface: Colors.white,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: kSoftBg,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        color: kInk,
        fontSize: 24,
        fontWeight: FontWeight.w800,
      ),
      iconTheme: IconThemeData(color: kInk),
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: Colors.white,
      selectedItemColor: kBrand,
      unselectedItemColor: Color(0xFF7C8796),
      type: BottomNavigationBarType.fixed,
      elevation: 0,
    ),
  );
}

ThemeData _buildDarkTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: kBrand,
    brightness: Brightness.dark,
    primary: kBrand,
    secondary: kAccent,
    surface: const Color(0xFF172033),
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: const Color(0xFF0B1220),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      titleTextStyle: TextStyle(
        color: Colors.white,
        fontSize: 24,
        fontWeight: FontWeight.w800,
      ),
      iconTheme: IconThemeData(color: Colors.white),
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      color: const Color(0xFF172033),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: Color(0xFF111827),
      selectedItemColor: kBrand,
      unselectedItemColor: Color(0xFF9AA4B2),
      type: BottomNavigationBarType.fixed,
      elevation: 0,
    ),
  );
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [Color(0xFFEAF7FF), Color(0xFFF8FBFF), Color(0xFFFFFFFF)],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 132,
                height: 132,
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: kBrand.withOpacity(0.22),
                      blurRadius: 28,
                      offset: const Offset(0, 16),
                    ),
                  ],
                ),
                child: ClipOval(
                  child: Image.asset('assets/images/app_logo.jpg', fit: BoxFit.cover),
                ),
              ),
              const SizedBox(height: 26),
              const Text(
                'نوادر المنشاوي',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                  color: kInk,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'تلاوات الحفلات بجودة مباشرة من الأرشيف',
                style: TextStyle(fontSize: 15, color: Color(0xFF667085)),
              ),
              const SizedBox(height: 32),
              const SizedBox(
                width: 34,
                height: 34,
                child: CircularProgressIndicator(strokeWidth: 3),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AuthFlow extends StatefulWidget {
  const AuthFlow({super.key, required this.onSuccess});

  final ValueChanged<String> onSuccess;

  @override
  State<AuthFlow> createState() => _AuthFlowState();
}

class _AuthFlowState extends State<AuthFlow> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _codeController = TextEditingController();
  final OtpClient _otpClient = OtpClient();
  String? _ticket;
  bool _sending = false;
  bool _verifying = false;
  String? _error;

  @override
  void dispose() {
    _emailController.dispose();
    _codeController.dispose();
    super.dispose();
  }

  Future<void> _sendCode() async {
    final email = _emailController.text.trim();
    if (!email.contains('@') || !email.contains('.')) {
      setState(() => _error = 'اكتب بريد إلكتروني صحيح.');
      return;
    }
    setState(() {
      _sending = true;
      _error = null;
    });
    try {
      final result = await _otpClient.send(email);
      if (!mounted) return;
      setState(() => _ticket = result.ticket);
      if (result.demoCode != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('كود التجربة: ${result.demoCode}')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم إرسال الكود إلى البريد.')),
        );
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'تعذر إرسال الكود الآن. تأكد من رابط خدمة OTP.');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _verifyCode() async {
    final email = _emailController.text.trim();
    final code = _codeController.text.trim();
    final ticket = _ticket;
    if (ticket == null) {
      setState(() => _error = 'اطلب الكود أولًا.');
      return;
    }
    if (code.length < 4) {
      setState(() => _error = 'اكتب الكود كاملًا.');
      return;
    }
    setState(() {
      _verifying = true;
      _error = null;
    });
    try {
      final ok = await _otpClient.verify(email: email, ticket: ticket, code: code);
      if (!mounted) return;
      if (ok) {
        widget.onSuccess(email);
      } else {
        setState(() => _error = 'الكود غير صحيح أو انتهت صلاحيته.');
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'فشل التحقق. حاول مرة أخرى.');
    } finally {
      if (mounted) setState(() => _verifying = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(22, 28, 22, 22),
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: Container(
                width: 78,
                height: 78,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: cs.surface,
                  boxShadow: [
                    BoxShadow(
                      color: kBrand.withOpacity(0.16),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: ClipOval(
                  child: Image.asset('assets/images/app_logo.jpg', fit: BoxFit.cover),
                ),
              ),
            ),
            const SizedBox(height: 26),
            Text(
              'أهلًا بك في نوادر المنشاوي',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 8),
            Text(
              'سجّل دخولك بالبريد لتظهر لك المكتبة وتحفظ المفضلة وتستمع للتلاوات مباشرة.',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: cs.onSurfaceVariant, height: 1.6),
            ),
            const SizedBox(height: 28),
            _GlassCard(
              child: Column(
                children: [
                  TextField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    textDirection: TextDirection.ltr,
                    decoration: const InputDecoration(
                      labelText: 'البريد الإلكتروني',
                      hintText: 'name@example.com',
                      prefixIcon: Icon(Icons.email_outlined),
                    ),
                  ),
                  const SizedBox(height: 14),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 240),
                    child: _ticket == null
                        ? const SizedBox.shrink()
                        : TextField(
                            key: const ValueKey('otp'),
                            controller: _codeController,
                            keyboardType: TextInputType.number,
                            textDirection: TextDirection.ltr,
                            maxLength: 6,
                            decoration: const InputDecoration(
                              labelText: 'كود التحقق',
                              hintText: '000000',
                              counterText: '',
                              prefixIcon: Icon(Icons.password_outlined),
                            ),
                          ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Text(_error!, style: const TextStyle(color: Colors.redAccent)),
                    ),
                  ],
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: FilledButton.icon(
                      onPressed: _sending || _verifying ? null : (_ticket == null ? _sendCode : _verifyCode),
                      icon: (_sending || _verifying)
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : Icon(_ticket == null ? Icons.mark_email_read_outlined : Icons.verified_user_outlined),
                      label: Text(_ticket == null ? 'إرسال الكود' : 'دخول التطبيق'),
                    ),
                  ),
                  if (_ticket != null) ...[
                    const SizedBox(height: 10),
                    TextButton(
                      onPressed: _sending ? null : _sendCode,
                      child: const Text('إرسال كود جديد'),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'ملاحظة: إرسال البريد الحقيقي يحتاج ربط رابط خدمة OTP من ملف backend المرفق. بدون الرابط يعمل وضع التجربة فقط.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}

class OtpSendResult {
  const OtpSendResult({required this.ticket, this.demoCode});
  final String ticket;
  final String? demoCode;
}

class OtpClient {
  static const String _endpoint = String.fromEnvironment('OTP_API_URL');

  Future<OtpSendResult> send(String email) async {
    if (_endpoint.trim().isEmpty) {
      final code = (100000 + Random().nextInt(900000)).toString();
      return OtpSendResult(ticket: 'local:$code', demoCode: code);
    }
    final base = _endpoint.endsWith('/') ? _endpoint.substring(0, _endpoint.length - 1) : _endpoint;
    final response = await http
        .post(
          Uri.parse('$base/send'),
          headers: const {'Content-Type': 'application/json'},
          body: jsonEncode({'email': email}),
        )
        .timeout(const Duration(seconds: 15));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('OTP send failed');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return OtpSendResult(ticket: 'remote:${data['requestId']}');
  }

  Future<bool> verify({required String email, required String ticket, required String code}) async {
    if (ticket.startsWith('local:')) {
      return ticket.substring(6) == code;
    }
    final requestId = ticket.replaceFirst('remote:', '');
    final base = _endpoint.endsWith('/') ? _endpoint.substring(0, _endpoint.length - 1) : _endpoint;
    final response = await http
        .post(
          Uri.parse('$base/verify'),
          headers: const {'Content-Type': 'application/json'},
          body: jsonEncode({'email': email, 'requestId': requestId, 'code': code}),
        )
        .timeout(const Duration(seconds: 15));
    if (response.statusCode < 200 || response.statusCode >= 300) return false;
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return data['ok'] == true;
  }
}

class MainShell extends StatefulWidget {
  const MainShell({
    super.key,
    required this.email,
    required this.themeMode,
    required this.onThemeChanged,
    required this.onLogout,
  });

  final String email;
  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onThemeChanged;
  final VoidCallback onLogout;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  final ArchiveRepository _repository = ArchiveRepository();
  final AudioPlayer _player = AudioPlayer();
  int _tabIndex = 0;
  List<ArchiveTrack> _tracks = const [];
  Set<String> _favorites = <String>{};
  ArchiveTrack? _currentTrack;
  bool _loading = true;
  String? _loadError;

  @override
  void initState() {
    super.initState();
    _loadEverything();
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  Future<void> _loadEverything() async {
    await Future.wait([_loadFavorites(), _loadTracks()]);
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList('favorites') ?? const <String>[];
    if (!mounted) return;
    setState(() => _favorites = list.toSet());
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('favorites', _favorites.toList());
  }

  Future<void> _loadTracks() async {
    setState(() {
      _loading = true;
      _loadError = null;
    });
    try {
      final tracks = await _repository.fetchTracks();
      if (!mounted) return;
      setState(() {
        _tracks = tracks;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _loadError = 'تعذر تحميل التلاوات من الأرشيف. تأكد من الاتصال بالإنترنت.';
      });
    }
  }

  Future<void> _playTrack(ArchiveTrack track) async {
    try {
      setState(() => _currentTrack = track);
      await _player.setUrl(track.url);
      await _player.play();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذر تشغيل التلاوة. جرب ملفًا آخر.')),
      );
    }
  }

  Future<void> _playNext() async {
    if (_tracks.isEmpty) return;
    final current = _currentTrack;
    final index = current == null ? -1 : _tracks.indexWhere((t) => t.fileName == current.fileName);
    final next = _tracks[(index + 1) % _tracks.length];
    await _playTrack(next);
  }

  Future<void> _playPrevious() async {
    if (_tracks.isEmpty) return;
    final current = _currentTrack;
    final index = current == null ? 0 : _tracks.indexWhere((t) => t.fileName == current.fileName);
    final prev = _tracks[(index - 1 + _tracks.length) % _tracks.length];
    await _playTrack(prev);
  }

  void _toggleFavorite(ArchiveTrack track) {
    setState(() {
      if (_favorites.contains(track.fileName)) {
        _favorites.remove(track.fileName);
      } else {
        _favorites.add(track.fileName);
      }
    });
    _saveFavorites();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(
        tracks: _tracks,
        favorites: _favorites,
        loading: _loading,
        loadError: _loadError,
        currentTrack: _currentTrack,
        player: _player,
        onRefresh: _loadTracks,
        onPlay: _playTrack,
        onNext: _playNext,
        onPrevious: _playPrevious,
        onToggleFavorite: _toggleFavorite,
      ),
      LibraryPage(
        tracks: _tracks,
        favorites: _favorites,
        loading: _loading,
        loadError: _loadError,
        onRefresh: _loadTracks,
        onPlay: _playTrack,
        onToggleFavorite: _toggleFavorite,
      ),
      FavoritesPage(
        tracks: _tracks.where((t) => _favorites.contains(t.fileName)).toList(),
        favorites: _favorites,
        onPlay: _playTrack,
        onToggleFavorite: _toggleFavorite,
      ),
      SettingsPage(
        email: widget.email,
        themeMode: widget.themeMode,
        onThemeChanged: widget.onThemeChanged,
        onLogout: widget.onLogout,
      ),
    ];

    return Scaffold(
      body: pages[_tabIndex],
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          decoration: BoxDecoration(
            color: Theme.of(context).bottomNavigationBarTheme.backgroundColor,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.06),
                blurRadius: 20,
                offset: const Offset(0, -8),
              ),
            ],
          ),
          child: BottomNavigationBar(
            currentIndex: _tabIndex,
            onTap: (value) => setState(() => _tabIndex = value),
            items: const [
              BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'الرئيسية'),
              BottomNavigationBarItem(icon: Icon(Icons.library_music_rounded), label: 'المكتبة'),
              BottomNavigationBarItem(icon: Icon(Icons.favorite_rounded), label: 'المفضلة'),
              BottomNavigationBarItem(icon: Icon(Icons.settings_rounded), label: 'الإعدادات'),
            ],
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({
    super.key,
    required this.tracks,
    required this.favorites,
    required this.loading,
    required this.loadError,
    required this.currentTrack,
    required this.player,
    required this.onRefresh,
    required this.onPlay,
    required this.onNext,
    required this.onPrevious,
    required this.onToggleFavorite,
  });

  final List<ArchiveTrack> tracks;
  final Set<String> favorites;
  final bool loading;
  final String? loadError;
  final ArchiveTrack? currentTrack;
  final AudioPlayer player;
  final Future<void> Function() onRefresh;
  final ValueChanged<ArchiveTrack> onPlay;
  final VoidCallback onNext;
  final VoidCallback onPrevious;
  final ValueChanged<ArchiveTrack> onToggleFavorite;

  @override
  Widget build(BuildContext context) {
    final visible = tracks.take(10).toList();
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: onRefresh,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
          children: [
            const AppHeader(title: 'نوادر المنشاوي'),
            const SizedBox(height: 18),
            const VerseCard(),
            const SizedBox(height: 16),
            PlayerCard(
              currentTrack: currentTrack,
              player: player,
              onNext: onNext,
              onPrevious: onPrevious,
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Text('تلاوات الحفلات', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                const Spacer(),
                Chip(
                  label: Text('${tracks.length} تلاوة'),
                  visualDensity: VisualDensity.compact,
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (loading) const LoadingList()
            else if (loadError != null) ErrorBox(message: loadError!, onRetry: onRefresh)
            else ...visible.map(
              (track) => TrackTile(
                track: track,
                isFavorite: favorites.contains(track.fileName),
                isPlaying: currentTrack?.fileName == track.fileName,
                onPlay: () => onPlay(track),
                onFavorite: () => onToggleFavorite(track),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class LibraryPage extends StatefulWidget {
  const LibraryPage({
    super.key,
    required this.tracks,
    required this.favorites,
    required this.loading,
    required this.loadError,
    required this.onRefresh,
    required this.onPlay,
    required this.onToggleFavorite,
  });

  final List<ArchiveTrack> tracks;
  final Set<String> favorites;
  final bool loading;
  final String? loadError;
  final Future<void> Function() onRefresh;
  final ValueChanged<ArchiveTrack> onPlay;
  final ValueChanged<ArchiveTrack> onToggleFavorite;

  @override
  State<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends State<LibraryPage> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final filtered = widget.tracks
        .where((track) => track.title.toLowerCase().contains(_query.trim().toLowerCase()))
        .toList();
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: widget.onRefresh,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
          children: [
            const AppHeader(title: 'المكتبة'),
            const SizedBox(height: 16),
            TextField(
              onChanged: (v) => setState(() => _query = v),
              decoration: const InputDecoration(
                hintText: 'ابحث باسم السورة أو التلاوة...',
                prefixIcon: Icon(Icons.search_rounded),
                filled: true,
              ),
            ),
            const SizedBox(height: 14),
            if (widget.loading) const LoadingList()
            else if (widget.loadError != null) ErrorBox(message: widget.loadError!, onRetry: widget.onRefresh)
            else if (filtered.isEmpty)
              const EmptyState(icon: Icons.search_off_rounded, text: 'لا توجد نتائج مطابقة.')
            else
              ...filtered.map(
                (track) => TrackTile(
                  track: track,
                  isFavorite: widget.favorites.contains(track.fileName),
                  onPlay: () => widget.onPlay(track),
                  onFavorite: () => widget.onToggleFavorite(track),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({
    super.key,
    required this.tracks,
    required this.favorites,
    required this.onPlay,
    required this.onToggleFavorite,
  });

  final List<ArchiveTrack> tracks;
  final Set<String> favorites;
  final ValueChanged<ArchiveTrack> onPlay;
  final ValueChanged<ArchiveTrack> onToggleFavorite;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
        children: [
          const AppHeader(title: 'المفضلة'),
          const SizedBox(height: 18),
          if (tracks.isEmpty)
            const EmptyState(icon: Icons.favorite_border_rounded, text: 'أضف التلاوات التي تحبها هنا.')
          else
            ...tracks.map(
              (track) => TrackTile(
                track: track,
                isFavorite: favorites.contains(track.fileName),
                onPlay: () => onPlay(track),
                onFavorite: () => onToggleFavorite(track),
              ),
            ),
        ],
      ),
    );
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({
    super.key,
    required this.email,
    required this.themeMode,
    required this.onThemeChanged,
    required this.onLogout,
  });

  final String email;
  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onThemeChanged;
  final VoidCallback onLogout;

  @override
  Widget build(BuildContext context) {
    final dark = themeMode == ThemeMode.dark;
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
        children: [
          const AppHeader(title: 'الإعدادات'),
          const SizedBox(height: 18),
          _GlassCard(
            child: Row(
              children: [
                ClipOval(
                  child: Image.asset('assets/images/app_logo.jpg', width: 60, height: 60, fit: BoxFit.cover),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('الحساب الحالي', style: TextStyle(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text(email, textDirection: TextDirection.ltr, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _GlassCard(
            child: Column(
              children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: dark,
                  onChanged: (value) => onThemeChanged(value ? ThemeMode.dark : ThemeMode.light),
                  title: const Text('الوضع الداكن'),
                  subtitle: const Text('تبديل شكل التطبيق بين الفاتح والداكن'),
                  secondary: Icon(dark ? Icons.dark_mode_rounded : Icons.light_mode_rounded),
                ),
                const Divider(height: 24),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.info_outline_rounded),
                  title: const Text('عن التطبيق'),
                  subtitle: const Text('تطبيق خفيف لتلاوات الحفلات من أرشيف المنشاوي.'),
                ),
                const Divider(height: 24),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.logout_rounded, color: Colors.redAccent),
                  title: const Text('تسجيل الخروج'),
                  onTap: onLogout,
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Center(
            child: Text(
              'إصدار 1.0.0 • صنع لخدمة القرآن الكريم',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
          ),
        ],
      ),
    );
  }
}

class AppHeader extends StatelessWidget {
  const AppHeader({super.key, required this.title});
  final String title;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            shape: BoxShape.circle,
          ),
          child: ClipOval(child: Image.asset('assets/images/app_logo.jpg', fit: BoxFit.cover)),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            title,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900),
          ),
        ),
        IconButton.filledTonal(
          onPressed: () {},
          icon: const Icon(Icons.more_horiz_rounded),
        ),
      ],
    );
  }
}

class VerseCard extends StatelessWidget {
  const VerseCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            kBrand.withOpacity(0.18),
            Theme.of(context).colorScheme.surface,
          ],
        ),
        border: Border.all(color: kBrand.withOpacity(0.22)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '﴿ الَّذِينَ آمَنُوا وَتَطْمَئِنُّ قُلُوبُهُم بِذِكْرِ اللَّهِ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ ﴾',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: kBrand,
                  height: 1.7,
                  fontWeight: FontWeight.w800,
                ),
          ),
          const SizedBox(height: 8),
          Center(
            child: Text(
              'سورة الرعد - الآية 28',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
          ),
        ],
      ),
    );
  }
}

class PlayerCard extends StatelessWidget {
  const PlayerCard({
    super.key,
    required this.currentTrack,
    required this.player,
    required this.onNext,
    required this.onPrevious,
  });

  final ArchiveTrack? currentTrack;
  final AudioPlayer player;
  final VoidCallback onNext;
  final VoidCallback onPrevious;

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: kBrand.withOpacity(0.14),
                ),
                child: const Icon(Icons.graphic_eq_rounded, color: kBrand),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      currentTrack?.title ?? 'اختر تلاوة للتشغيل',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      currentTrack == null ? 'متوقف' : 'الشيخ محمد صديق المنشاوي',
                      style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          StreamBuilder<Duration>(
            stream: player.positionStream,
            builder: (context, snapshot) {
              final position = snapshot.data ?? Duration.zero;
              final duration = player.duration ?? Duration.zero;
              final max = maxDurationMs(duration);
              final value = position.inMilliseconds.clamp(0, max).toDouble();
              return Slider(
                value: value,
                min: 0,
                max: max.toDouble(),
                onChanged: duration == Duration.zero
                    ? null
                    : (v) => player.seek(Duration(milliseconds: v.round())),
              );
            },
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                onPressed: onPrevious,
                icon: const Icon(Icons.skip_next_rounded),
                tooltip: 'السابق',
              ),
              const SizedBox(width: 8),
              StreamBuilder<PlayerState>(
                stream: player.playerStateStream,
                builder: (context, snapshot) {
                  final state = snapshot.data;
                  final processing = state?.processingState;
                  final playing = state?.playing ?? false;
                  final busy = processing == ProcessingState.loading || processing == ProcessingState.buffering;
                  return FilledButton(
                    style: FilledButton.styleFrom(
                      shape: const CircleBorder(),
                      padding: const EdgeInsets.all(18),
                    ),
                    onPressed: currentTrack == null
                        ? null
                        : () {
                            if (playing) {
                              player.pause();
                            } else {
                              player.play();
                            }
                          },
                    child: busy
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded, size: 34),
                  );
                },
              ),
              const SizedBox(width: 8),
              IconButton(
                onPressed: onNext,
                icon: const Icon(Icons.skip_previous_rounded),
                tooltip: 'التالي',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

int maxDurationMs(Duration duration) {
  final ms = duration.inMilliseconds;
  if (ms <= 0) return 1;
  return ms;
}

class TrackTile extends StatelessWidget {
  const TrackTile({
    super.key,
    required this.track,
    required this.isFavorite,
    required this.onPlay,
    required this.onFavorite,
    this.isPlaying = false,
  });

  final ArchiveTrack track;
  final bool isFavorite;
  final bool isPlaying;
  final VoidCallback onPlay;
  final VoidCallback onFavorite;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onPlay,
        child: Ink(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: isPlaying ? kBrand.withOpacity(0.11) : cs.surface,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: isPlaying ? kBrand.withOpacity(0.45) : Colors.transparent),
          ),
          child: Row(
            children: [
              CircleAvatar(
                radius: 24,
                backgroundColor: kBrand.withOpacity(0.13),
                child: Icon(isPlaying ? Icons.equalizer_rounded : Icons.play_arrow_rounded, color: kBrand),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      track.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      track.prettySize,
                      style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: onFavorite,
                icon: Icon(isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded),
                color: isFavorite ? Colors.redAccent : cs.onSurfaceVariant,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LoadingList extends StatelessWidget {
  const LoadingList({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(
        5,
        (index) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Container(
            height: 76,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Center(child: LinearProgressIndicator(minHeight: 2)),
          ),
        ),
      ),
    );
  }
}

class ErrorBox extends StatelessWidget {
  const ErrorBox({super.key, required this.message, required this.onRetry});
  final String message;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      child: Column(
        children: [
          const Icon(Icons.wifi_off_rounded, size: 48, color: Colors.orange),
          const SizedBox(height: 10),
          Text(message, textAlign: TextAlign.center),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: onRetry,
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('إعادة المحاولة'),
          ),
        ],
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      child: Column(
        children: [
          Icon(icon, size: 54, color: Theme.of(context).colorScheme.onSurfaceVariant),
          const SizedBox(height: 12),
          Text(text, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class _GlassCard extends StatelessWidget {
  const _GlassCard({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(26),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.035),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: child,
    );
  }
}

class ArchiveTrack {
  const ArchiveTrack({
    required this.title,
    required this.fileName,
    required this.url,
    required this.sizeBytes,
  });

  final String title;
  final String fileName;
  final String url;
  final int sizeBytes;

  String get prettySize {
    if (sizeBytes <= 0) return 'ملف صوتي';
    final mb = sizeBytes / (1024 * 1024);
    if (mb >= 1) return '${mb.toStringAsFixed(1)} ميجا';
    final kb = sizeBytes / 1024;
    return '${kb.toStringAsFixed(0)} كيلوبايت';
  }
}

class ArchiveRepository {
  Future<List<ArchiveTrack>> fetchTracks() async {
    final uri = Uri.parse('https://archive.org/metadata/$kArchiveIdentifier');
    final response = await http.get(uri).timeout(const Duration(seconds: 20));
    if (response.statusCode != 200) {
      throw Exception('Archive metadata failed');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final files = data['files'];
    if (files is! List) return const [];
    final tracks = <ArchiveTrack>[];
    for (final entry in files) {
      if (entry is! Map) continue;
      final rawName = (entry['name'] ?? '').toString();
      final decodedName = Uri.decodeFull(rawName);
      final lower = decodedName.toLowerCase();
      final isAudio = lower.endsWith('.mp3') ||
          lower.endsWith('.m4a') ||
          lower.endsWith('.ogg') ||
          lower.endsWith('.wav') ||
          lower.endsWith('.flac');
      if (!decodedName.startsWith(kArchiveFolder) || !isAudio) continue;
      final cleanTitle = _cleanTitle(decodedName);
      final size = int.tryParse((entry['size'] ?? '0').toString()) ?? 0;
      tracks.add(
        ArchiveTrack(
          title: cleanTitle,
          fileName: decodedName,
          url: 'https://archive.org/download/$kArchiveIdentifier/${_encodePath(decodedName)}',
          sizeBytes: size,
        ),
      );
    }
    tracks.sort((a, b) => a.title.compareTo(b.title));
    return tracks;
  }

  String _cleanTitle(String name) {
    var title = name.replaceFirst(kArchiveFolder, '');
    title = title.split('/').last;
    title = title.replaceAll(RegExp(r'\.(mp3|m4a|ogg|wav|flac)$', caseSensitive: false), '');
    title = title.replaceAll(RegExp(r'^\d+[-_\s]*'), '');
    title = title.replaceAll('_', ' ').replaceAll('-', ' ');
    title = title.replaceAll(RegExp(r'\s+'), ' ').trim();
    return title.isEmpty ? 'تلاوة من الحفلات' : title;
  }

  String _encodePath(String path) {
    return path.split('/').map(Uri.encodeComponent).join('/');
  }
}
