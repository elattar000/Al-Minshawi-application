# نوادر المنشاوي - تطبيق Flutter

تطبيق عربي RTL لتشغيل تلاوات الحفلات من أرشيف الشيخ محمد صديق المنشاوي على Internet Archive، مع واجهة حديثة، شاشة تحميل، تسجيل دخول بالبريد وكود تحقق، مشغل صوت، مكتبة، مفضلة، وإعدادات الوضع الداكن.

## المهم قبل البناء

بيئة المحادثة الحالية لا تحتوي Flutter SDK ولا Android SDK، لذلك لا يمكن إخراج ملف APK من هنا مباشرة. هذا الملف يحتوي مشروع Flutter جاهز ومقسم، وتقدر تبنيه على جهازك أو على خدمة بناء تدعم Flutter.

## المميزات الموجودة

- واجهة عربية كاملة واتجاه RTL.
- Splash / Loading screen بصورة الشيخ كشعار.
- تسجيل دخول بالبريد وكود تحقق.
- ربط اختياري بخادم OTP حقيقي داخل مجلد `backend/otp_server`.
- جلب التلاوات تلقائيًا من:
  `https://archive.org/metadata/Encyclopedia-of-Alminshawi`
- فلترة مجلد: `04-تلاوات الحفلات/`.
- تشغيل مباشر للتلاوات من روابط Archive.org.
- شريط سفلي: الرئيسية، المكتبة، المفضلة، الإعدادات.
- بحث داخل المكتبة.
- حفظ المفضلة على الجهاز.
- زر الوضع الداكن.

## تشغيل التطبيق على جهازك

افتح Terminal داخل المجلد وشغل:

```bash
flutter create . --platforms=android
flutter pub get
flutter run
```

## إضافة صلاحية الإنترنت في أندرويد

بعد أمر `flutter create .`، افتح الملف:

```text
android/app/src/main/AndroidManifest.xml
```

وتأكد أن بدايته تحتوي:

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

أو انسخ الملف الموجود في:

```text
android_patch/app/src/main/AndroidManifest.xml
```

مكان ملف Manifest الأصلي.

## بناء APK

```bash
flutter build apk --release
```

ستجد الملف هنا:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## تسجيل الدخول بالكود عبر البريد

بدون خادم OTP، التطبيق يعمل بوضع تجربة ويظهر الكود داخل SnackBar على الشاشة. عشان الكود يوصلك على الإيميل فعل الخادم المرفق:

```bash
cd backend/otp_server
npm install
cp .env.example .env
```

عدّل بيانات SMTP داخل `.env` ثم شغل:

```bash
npm start
```

ارفع الخادم على Render / Railway / VPS وخذ الرابط، ثم ابني التطبيق هكذا:

```bash
flutter build apk --release --dart-define=OTP_API_URL=https://your-otp-server.com
```

الروابط المطلوبة في الخادم:

- `POST /send` لإرسال الكود.
- `POST /verify` للتحقق من الكود.

## ملاحظات مهمة

- إرسال كود حقيقي من التطبيق مباشرة بدون خادم ليس آمنًا لأن بيانات البريد أو SMTP ستتسرب داخل APK.
- التطبيق يشغل التلاوات Streaming من archive.org، لذلك حجم APK نفسه يظل صغيرًا نسبيًا لأن الملفات الصوتية ليست داخله.
- حجم APK النهائي يعتمد على نسخة Flutter والإضافات، وغالبًا يكون أكبر من تطبيق Native بسيط لأن Flutter يضيف محركه الخاص.

## تغيير الاسم أو اللوجو

- الصور داخل: `assets/images/`
- الاسم داخل `pubspec.yaml` وملفات Android بعد إنشاء المشروع.
- لوجو الواجهة الحالي مأخوذ من الصورة المرسلة ومضغوط للاستخدام داخل التطبيق.
