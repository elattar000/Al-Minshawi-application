import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'firebase_options.dart';

const Color kPrimary = Color(0xFF2D9CDB);
const Color kSecondary = Color(0xFF56CCF2);
const Color kNight = Color(0xFF0B1220);
const Color kInk = Color(0xFF111827);
const Color kMuted = Color(0xFF667085);
const Color kWarm = Color(0xFFFFB020);
const String kDefaultArchiveIdentifier = 'Encyclopedia-of-Alminshawi';


class AppConfig {
  AppConfig._();
  static final AppConfig instance = AppConfig._();

  String archiveIdentifier = kDefaultArchiveIdentifier;
  bool maintenance = false;
  String maintenanceMessage = 'التطبيق تحت الصيانة حاليًا، سنعود قريبًا بإذن الله.';
  String featuredMessage = 'تلاوات مختارة من نوادر الشيخ محمد صديق المنشاوي';
  int forceUpdateMinBuild = 1;

  Future<void> load() async {
    try {
      final remoteConfig = FirebaseRemoteConfig.instance;
      await remoteConfig.setDefaults(<String, dynamic>{
        'archive_identifier': kDefaultArchiveIdentifier,
        'app_maintenance': false,
        'maintenance_message': maintenanceMessage,
        'featured_message': featuredMessage,
        'force_update_min_build': 1,
      });
      await remoteConfig.setConfigSettings(RemoteConfigSettings(
        fetchTimeout: const Duration(seconds: 10),
        minimumFetchInterval: const Duration(minutes: 30),
      ));
      await remoteConfig.fetchAndActivate();
      final nextArchive = remoteConfig.getString('archive_identifier').trim();
      archiveIdentifier = nextArchive.isEmpty ? kDefaultArchiveIdentifier : nextArchive;
      maintenance = remoteConfig.getBool('app_maintenance');
      maintenanceMessage = remoteConfig.getString('maintenance_message').trim().isEmpty
          ? maintenanceMessage
          : remoteConfig.getString('maintenance_message').trim();
      featuredMessage = remoteConfig.getString('featured_message').trim().isEmpty
          ? featuredMessage
          : remoteConfig.getString('featured_message').trim();
      forceUpdateMinBuild = remoteConfig.getInt('force_update_min_build');
    } catch (_) {
      archiveIdentifier = kDefaultArchiveIdentifier;
    }
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await AppConfig.instance.load();
  runApp(const NawaderProfessionalApp());
}

class NawaderProfessionalApp extends StatefulWidget {
  const NawaderProfessionalApp({super.key});

  @override
  State<NawaderProfessionalApp> createState() => _NawaderProfessionalAppState();
}

class _NawaderProfessionalAppState extends State<NawaderProfessionalApp> {
  bool _booting = true;
  bool _isLoggedIn = false;
  ThemeMode _themeMode = ThemeMode.light;
  String _email = '';
  StreamSubscription<User?>? _authSubscription;

  @override
  void initState() {
    super.initState();
    _loadAppState();
  }

  @override
  void dispose() {
    _authSubscription?.cancel();
    super.dispose();
  }

  Future<void> _loadAppState() async {
    final prefs = await SharedPreferences.getInstance();
    final user = FirebaseAuth.instance.currentUser;
    await Future<void>.delayed(const Duration(milliseconds: 1100));
    if (!mounted) return;
    setState(() {
      _isLoggedIn = user != null;
      _email = user?.email ?? '';
      _themeMode = (prefs.getBool('dark_mode') ?? false) ? ThemeMode.dark : ThemeMode.light;
      _booting = false;
    });
    _authSubscription = FirebaseAuth.instance.authStateChanges().listen((user) {
      if (!mounted) return;
      setState(() {
        _isLoggedIn = user != null;
        _email = user?.email ?? '';
      });
    });
  }

  Future<void> _login(String email, String password, bool createAccount) async {
    if (createAccount) {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email, password: password);
    } else {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: email, password: password);
    }
  }

  Future<void> _logout() async {
    await FirebaseAuth.instance.signOut();
  }

  Future<void> _changeTheme(ThemeMode mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('dark_mode', mode == ThemeMode.dark);
    setState(() => _themeMode = mode);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'نوادر المنشاوي',
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      themeMode: _themeMode,
      theme: _lightTheme(),
      darkTheme: _darkTheme(),
      home: AnimatedSwitcher(
        duration: const Duration(milliseconds: 450),
        child: _booting
            ? const SplashScreen(key: ValueKey('splash'))
            : AppConfig.instance.maintenance
                ? MaintenanceScreen(key: const ValueKey('maintenance'), message: AppConfig.instance.maintenanceMessage)
                : _isLoggedIn
                    ? MainShell(
                    key: const ValueKey('main'),
                    email: _email,
                    themeMode: _themeMode,
                    onThemeChanged: _changeTheme,
                    onLogout: _logout,
                  )
                : LoginScreen(
                    key: const ValueKey('login'),
                    onLogin: _login,
                  ),
      ),
    );
  }
}

ThemeData _lightTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: kPrimary,
    brightness: Brightness.light,
    primary: kPrimary,
    secondary: kSecondary,
    surface: Colors.white,
  );
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'sans',
    colorScheme: scheme,
    scaffoldBackgroundColor: const Color(0xFFF4F8FC),
    textTheme: const TextTheme(
      headlineLarge: TextStyle(fontWeight: FontWeight.w900, letterSpacing: -0.8),
      headlineMedium: TextStyle(fontWeight: FontWeight.w900, letterSpacing: -0.5),
      titleLarge: TextStyle(fontWeight: FontWeight.w900),
      titleMedium: TextStyle(fontWeight: FontWeight.w800),
      bodyMedium: TextStyle(height: 1.45),
    ),
    appBarTheme: const AppBarTheme(
      elevation: 0,
      backgroundColor: Colors.transparent,
      foregroundColor: kInk,
      centerTitle: false,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(20),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(20),
        borderSide: const BorderSide(color: Color(0xFFE4EAF2)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(20),
        borderSide: const BorderSide(color: kPrimary, width: 1.4),
      ),
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
    ),
  );
}

ThemeData _darkTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: kPrimary,
    brightness: Brightness.dark,
    primary: kPrimary,
    secondary: kSecondary,
    surface: const Color(0xFF141C2F),
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: kNight,
    textTheme: const TextTheme(
      headlineLarge: TextStyle(fontWeight: FontWeight.w900, letterSpacing: -0.8),
      headlineMedium: TextStyle(fontWeight: FontWeight.w900, letterSpacing: -0.5),
      titleLarge: TextStyle(fontWeight: FontWeight.w900),
      titleMedium: TextStyle(fontWeight: FontWeight.w800),
      bodyMedium: TextStyle(height: 1.45),
    ),
    appBarTheme: const AppBarTheme(
      elevation: 0,
      backgroundColor: Colors.transparent,
      foregroundColor: Colors.white,
      centerTitle: false,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFF162033),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(20),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(20),
        borderSide: const BorderSide(color: Color(0xFF24324C)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(20),
        borderSide: const BorderSide(color: kSecondary, width: 1.4),
      ),
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      color: const Color(0xFF141C2F),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
    ),
  );
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [Color(0xFFE6F6FF), Color(0xFFF7FBFF), Colors.white],
          ),
        ),
        child: Stack(
          children: [
            const Positioned(top: -90, right: -80, child: _GlowBall(size: 240, color: kSecondary)),
            const Positioned(bottom: -110, left: -70, child: _GlowBall(size: 260, color: kPrimary)),
            Center(
              child: FadeTransition(
                opacity: CurvedAnimation(parent: _controller, curve: Curves.easeOut),
                child: ScaleTransition(
                  scale: Tween<double>(begin: 0.86, end: 1).animate(
                    CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 134,
                        height: 134,
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: kPrimary.withOpacity(0.20),
                              blurRadius: 42,
                              offset: const Offset(0, 24),
                            ),
                          ],
                        ),
                        child: ClipOval(child: Image.asset('assets/images/app_logo.jpg', fit: BoxFit.cover)),
                      ),
                      const SizedBox(height: 28),
                      const Text(
                        'نوادر المنشاوي',
                        style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: kInk, letterSpacing: -1.2),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'مكتبة مرتّبة لتلاوات الشيخ محمد صديق المنشاوي',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 15.5, color: kMuted),
                      ),
                      const SizedBox(height: 34),
                      const _LoadingWave(),
                      const SizedBox(height: 14),
                      const Text('جاري تجهيز المكتبة والمشغل...', style: TextStyle(color: kMuted, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LoadingWave extends StatefulWidget {
  const _LoadingWave();

  @override
  State<_LoadingWave> createState() => _LoadingWaveState();
}

class _LoadingWaveState extends State<_LoadingWave> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 850))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: List.generate(5, (i) {
            final t = sin((_c.value * pi) + i * .55).abs();
            return Container(
              width: 6,
              height: 16 + (22 * t),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(99),
                gradient: const LinearGradient(colors: [kPrimary, kSecondary], begin: Alignment.bottomCenter, end: Alignment.topCenter),
              ),
            );
          }),
        );
      },
    );
  }
}

class _GlowBall extends StatelessWidget {
  const _GlowBall({required this.size, required this.color});

  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(.18)),
      child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30), child: const SizedBox.expand()),
    );
  }
}


class MaintenanceScreen extends StatelessWidget {
  const MaintenanceScreen({super.key, required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const Positioned(top: -100, right: -60, child: _GlowBall(size: 250, color: kSecondary)),
          const Positioned(bottom: -120, left: -80, child: _GlowBall(size: 280, color: kPrimary)),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: _GlassPanel(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.construction_rounded, size: 56, color: kWarm),
                    const SizedBox(height: 18),
                    Text('صيانة مؤقتة', style: Theme.of(context).textTheme.headlineMedium),
                    const SizedBox(height: 10),
                    Text(message, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.onLogin});

  final Future<void> Function(String email, String password, bool createAccount) onLogin;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _obscure = true;
  bool _busy = false;
  bool _createAccount = false;
  String? _error;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final email = _email.text.trim();
    final pass = _password.text.trim();
    if (!email.contains('@') || !email.contains('.')) {
      setState(() => _error = 'اكتب بريد إلكتروني صحيح.');
      return;
    }
    if (pass.length < 6) {
      setState(() => _error = 'كلمة المرور لا تقل عن 6 حروف.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await widget.onLogin(email, pass, _createAccount);
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      setState(() => _error = _friendlyAuthError(e));
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = 'حدث خطأ في الاتصال بـ Firebase. جرّب مرة أخرى.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _friendlyAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
        return 'هذا البريد غير مسجل. اضغط إنشاء حساب لأول مرة.';
      case 'wrong-password':
      case 'invalid-credential':
        return 'البريد أو كلمة المرور غير صحيحة.';
      case 'email-already-in-use':
        return 'هذا البريد مسجل بالفعل. اختر دخول بدل إنشاء حساب.';
      case 'weak-password':
        return 'كلمة المرور ضعيفة. اجعلها 6 أحرف أو أكثر.';
      case 'network-request-failed':
        return 'تحقق من الاتصال بالإنترنت.';
      case 'operation-not-allowed':
        return 'فعّل Email/Password من Authentication داخل Firebase.';
      default:
        return e.message ?? 'تعذر تسجيل الدخول.';
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: Stack(
        children: [
          const Positioned(top: -100, right: -60, child: _GlowBall(size: 250, color: kSecondary)),
          const Positioned(bottom: -120, left: -80, child: _GlowBall(size: 280, color: kPrimary)),
          SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(22, 26, 22, 22),
              children: [
                _TopLogo(compact: false),
                const SizedBox(height: 28),
                Text('مرحبًا بك', style: Theme.of(context).textTheme.headlineLarge?.copyWith(fontSize: 38)),
                const SizedBox(height: 8),
                Text(
                  'سجّل دخولك بالبريد وكلمة المرور. الدخول هنا متصل بمشروع Firebase الذي أرسلته.',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: cs.onSurfaceVariant, height: 1.6),
                ),
                const SizedBox(height: 26),
                _GlassPanel(
                  child: Column(
                    children: [
                      TextField(
                        controller: _email,
                        keyboardType: TextInputType.emailAddress,
                        textDirection: TextDirection.ltr,
                        decoration: const InputDecoration(
                          labelText: 'البريد الإلكتروني',
                          hintText: 'name@example.com',
                          prefixIcon: Icon(Icons.mail_outline_rounded),
                        ),
                      ),
                      const SizedBox(height: 14),
                      TextField(
                        controller: _password,
                        obscureText: _obscure,
                        textDirection: TextDirection.ltr,
                        decoration: InputDecoration(
                          labelText: 'كلمة المرور',
                          prefixIcon: const Icon(Icons.lock_outline_rounded),
                          suffixIcon: IconButton(
                            icon: Icon(_obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                            onPressed: () => setState(() => _obscure = !_obscure),
                          ),
                        ),
                      ),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 250),
                        child: _error == null
                            ? const SizedBox(height: 14)
                            : Padding(
                                padding: const EdgeInsets.only(top: 12),
                                child: Row(
                                  children: [
                                    const Icon(Icons.info_outline, color: Colors.redAccent, size: 18),
                                    const SizedBox(width: 8),
                                    Expanded(child: Text(_error!, style: const TextStyle(color: Colors.redAccent))),
                                  ],
                                ),
                              ),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        height: 56,
                        child: FilledButton.icon(
                          onPressed: _busy ? null : _submit,
                          icon: _busy
                              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                              : const Icon(Icons.login_rounded),
                          label: Text(_createAccount ? 'إنشاء حساب والدخول' : 'دخول التطبيق', style: const TextStyle(fontWeight: FontWeight.w900)),
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextButton(
                        onPressed: _busy ? null : () => setState(() => _createAccount = !_createAccount),
                        child: Text(_createAccount ? 'عندي حساب بالفعل' : 'إنشاء حساب لأول مرة'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                _InfoStrip(
                  icon: Icons.security_rounded,
                  title: 'Firebase مفعل',
                  text: 'Email/Password يعمل من Firebase Auth، والتلاوات والرسائل يمكن تحديثها من Remote Config بدون تنزيل APK جديد.',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({
    super.key,
    required this.email,
    required this.themeMode,
    required this.onThemeChanged,
    required this.onLogout,
  });

  final String email;
  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onThemeChanged;
  final VoidCallback onLogout;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  final ArchiveRepository _repo = ArchiveRepository();
  final AudioPlayer _player = AudioPlayer();
  final PageController _pageController = PageController();

  int _page = 0;
  bool _loading = true;
  String? _error;
  List<ArchiveTrack> _tracks = const [];
  List<String> _favorites = const [];
  String _section = 'الكل';
  String _query = '';
  ArchiveTrack? _current;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
    _loadTracks();
  }

  @override
  void dispose() {
    _player.dispose();
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _favorites = prefs.getStringList('favorites') ?? const []);
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('favorites', _favorites);
  }

  Future<void> _loadTracks() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final tracks = await _repo.fetchTracks();
      if (!mounted) return;
      setState(() {
        _tracks = tracks;
        _section = _preferredInitialSection(tracks);
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'تعذر تحميل التلاوات من الأرشيف. تأكد من الإنترنت ثم جرّب تحديث المكتبة.';
      });
    }
  }

  String _preferredInitialSection(List<ArchiveTrack> tracks) {
    final sections = tracks.map((e) => e.section).toSet().toList();
    final concerts = sections.where((e) => e.contains('الحفلات') || e.contains('المحافل')).toList();
    return concerts.isNotEmpty ? concerts.first : 'الكل';
  }

  List<String> get _sections {
    final set = _tracks.map((e) => e.section).where((e) => e.trim().isNotEmpty).toSet().toList();
    set.sort((a, b) {
      final ap = a.contains('الحفلات') || a.contains('المحافل') ? 0 : 1;
      final bp = b.contains('الحفلات') || b.contains('المحافل') ? 0 : 1;
      if (ap != bp) return ap.compareTo(bp);
      return a.compareTo(b);
    });
    return ['الكل', ...set.take(12)];
  }

  List<ArchiveTrack> get _visibleTracks {
    Iterable<ArchiveTrack> data = _tracks;
    if (_section != 'الكل') data = data.where((e) => e.section == _section);
    final q = _query.trim();
    if (q.isNotEmpty) {
      data = data.where((e) => e.title.contains(q) || e.section.contains(q) || e.fileName.contains(q));
    }
    return data.toList();
  }

  List<ArchiveTrack> get _favoriteTracks => _tracks.where((e) => _favorites.contains(e.id)).toList();

  Future<void> _play(ArchiveTrack track) async {
    try {
      setState(() => _current = track);
      await _player.setUrl(track.url);
      await _player.play();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر تشغيل التلاوة. جرّب تلاوة أخرى.')));
    }
  }

  Future<void> _togglePlayPause() async {
    if (_current == null && _visibleTracks.isNotEmpty) {
      await _play(_visibleTracks.first);
      return;
    }
    if (_player.playing) {
      await _player.pause();
    } else {
      await _player.play();
    }
  }

  Future<void> _playOffset(int offset) async {
    final current = _current;
    final list = _visibleTracks.isEmpty ? _tracks : _visibleTracks;
    if (list.isEmpty) return;
    final index = current == null ? 0 : max(0, list.indexWhere((e) => e.id == current.id));
    final next = list[(index + offset).clamp(0, list.length - 1)];
    await _play(next);
  }

  Future<void> _download(ArchiveTrack track) async {
    final uri = Uri.parse(track.url);
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لم أستطع فتح رابط التحميل.')));
    }
  }

  void _toggleFavorite(ArchiveTrack track) {
    final next = [..._favorites];
    if (next.contains(track.id)) {
      next.remove(track.id);
    } else {
      next.add(track.id);
    }
    setState(() => _favorites = next);
    _saveFavorites();
  }

  void _go(int index) {
    setState(() => _page = index);
    _pageController.animateToPage(index, duration: const Duration(milliseconds: 360), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeTab(
        loading: _loading,
        error: _error,
        tracks: _visibleTracks,
        allTracks: _tracks,
        sections: _sections,
        selectedSection: _section,
        onRefresh: _loadTracks,
        onSectionChanged: (s) => setState(() => _section = s),
        favorites: _favorites,
        current: _current,
        onPlay: _play,
        onFavorite: _toggleFavorite,
        onDownload: _download,
      ),
      LibraryTab(
        loading: _loading,
        tracks: _visibleTracks,
        query: _query,
        onQueryChanged: (v) => setState(() => _query = v),
        favorites: _favorites,
        current: _current,
        onPlay: _play,
        onFavorite: _toggleFavorite,
        onDownload: _download,
      ),
      FavoritesTab(
        tracks: _favoriteTracks,
        current: _current,
        favorites: _favorites,
        onPlay: _play,
        onFavorite: _toggleFavorite,
        onDownload: _download,
      ),
      SettingsTab(
        email: widget.email,
        themeMode: widget.themeMode,
        onThemeChanged: widget.onThemeChanged,
        onLogout: widget.onLogout,
      ),
    ];

    return Scaffold(
      extendBody: true,
      body: Stack(
        children: [
          PageView(
            controller: _pageController,
            onPageChanged: (i) => setState(() => _page = i),
            children: pages,
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                MiniPlayer(
                  player: _player,
                  track: _current,
                  onPlayPause: _togglePlayPause,
                  onNext: () => _playOffset(1),
                  onPrev: () => _playOffset(-1),
                ),
                AppBottomBar(currentIndex: _page, onTap: _go),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({
    super.key,
    required this.loading,
    required this.error,
    required this.tracks,
    required this.allTracks,
    required this.sections,
    required this.selectedSection,
    required this.onSectionChanged,
    required this.onRefresh,
    required this.favorites,
    required this.current,
    required this.onPlay,
    required this.onFavorite,
    required this.onDownload,
  });

  final bool loading;
  final String? error;
  final List<ArchiveTrack> tracks;
  final List<ArchiveTrack> allTracks;
  final List<String> sections;
  final String selectedSection;
  final ValueChanged<String> onSectionChanged;
  final Future<void> Function() onRefresh;
  final List<String> favorites;
  final ArchiveTrack? current;
  final ValueChanged<ArchiveTrack> onPlay;
  final ValueChanged<ArchiveTrack> onFavorite;
  final ValueChanged<ArchiveTrack> onDownload;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: RefreshIndicator(
        onRefresh: onRefresh,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 190),
          children: [
            const _HeaderBar(),
            const SizedBox(height: 18),
            const HeroQuranCard(),
            const SizedBox(height: 18),
            StatsRow(total: allTracks.length, favorites: favorites.length, sections: max(0, sections.length - 1)),
            const SizedBox(height: 22),
            _SectionTitle(title: 'الأقسام', action: loading ? null : '${tracks.length} تلاوة'),
            const SizedBox(height: 12),
            SectionsCarousel(sections: sections, selected: selectedSection, onChanged: onSectionChanged),
            const SizedBox(height: 20),
            _SectionTitle(title: 'تلاوات مختارة', action: 'اسحب للتحديث'),
            const SizedBox(height: 12),
            if (loading) ...List.generate(5, (i) => const TrackSkeleton()).separatedBy(const SizedBox(height: 12))
            else if (error != null)
              ErrorCard(message: error!, onRetry: onRefresh)
            else if (tracks.isEmpty)
              EmptyState(icon: Icons.folder_off_rounded, title: 'لا توجد تلاوات', text: 'القسم الحالي لا يحتوي على ملفات صوتية ظاهرة.')
            else
              ...tracks.take(18).toList().asMap().entries.map((entry) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: AnimatedListItem(
                    index: entry.key,
                    child: TrackCard(
                      track: entry.value,
                      isPlaying: current?.id == entry.value.id,
                      isFavorite: favorites.contains(entry.value.id),
                      onPlay: () => onPlay(entry.value),
                      onFavorite: () => onFavorite(entry.value),
                      onDownload: () => onDownload(entry.value),
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}

class LibraryTab extends StatelessWidget {
  const LibraryTab({
    super.key,
    required this.loading,
    required this.tracks,
    required this.query,
    required this.onQueryChanged,
    required this.favorites,
    required this.current,
    required this.onPlay,
    required this.onFavorite,
    required this.onDownload,
  });

  final bool loading;
  final List<ArchiveTrack> tracks;
  final String query;
  final ValueChanged<String> onQueryChanged;
  final List<String> favorites;
  final ArchiveTrack? current;
  final ValueChanged<ArchiveTrack> onPlay;
  final ValueChanged<ArchiveTrack> onFavorite;
  final ValueChanged<ArchiveTrack> onDownload;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 190),
        children: [
          const _HeaderBar(title: 'المكتبة'),
          const SizedBox(height: 18),
          TextField(
            onChanged: onQueryChanged,
            decoration: const InputDecoration(
              hintText: 'ابحث باسم السورة أو البلد أو التاريخ...',
              prefixIcon: Icon(Icons.search_rounded),
            ),
          ),
          const SizedBox(height: 18),
          _SectionTitle(title: 'نتائج المكتبة', action: '${tracks.length} تلاوة'),
          const SizedBox(height: 12),
          if (loading) ...List.generate(6, (_) => const TrackSkeleton()).separatedBy(const SizedBox(height: 12))
          else if (tracks.isEmpty)
            const EmptyState(icon: Icons.search_off_rounded, title: 'لا توجد نتائج', text: 'جرّب كلمة بحث أبسط أو غيّر القسم من الرئيسية.')
          else
            ...tracks.asMap().entries.map((entry) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: AnimatedListItem(
                    index: entry.key,
                    child: TrackCard(
                      track: entry.value,
                      isPlaying: current?.id == entry.value.id,
                      isFavorite: favorites.contains(entry.value.id),
                      onPlay: () => onPlay(entry.value),
                      onFavorite: () => onFavorite(entry.value),
                      onDownload: () => onDownload(entry.value),
                    ),
                  ),
                )),
        ],
      ),
    );
  }
}

class FavoritesTab extends StatelessWidget {
  const FavoritesTab({
    super.key,
    required this.tracks,
    required this.current,
    required this.favorites,
    required this.onPlay,
    required this.onFavorite,
    required this.onDownload,
  });

  final List<ArchiveTrack> tracks;
  final ArchiveTrack? current;
  final List<String> favorites;
  final ValueChanged<ArchiveTrack> onPlay;
  final ValueChanged<ArchiveTrack> onFavorite;
  final ValueChanged<ArchiveTrack> onDownload;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 190),
        children: [
          const _HeaderBar(title: 'المفضلة'),
          const SizedBox(height: 18),
          if (tracks.isEmpty)
            const EmptyState(
              icon: Icons.favorite_border_rounded,
              title: 'المفضلة فارغة',
              text: 'اضغط على القلب بجانب أي تلاوة حتى تظهر هنا بسرعة.',
            )
          else
            ...tracks.asMap().entries.map((entry) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: AnimatedListItem(
                    index: entry.key,
                    child: TrackCard(
                      track: entry.value,
                      isPlaying: current?.id == entry.value.id,
                      isFavorite: favorites.contains(entry.value.id),
                      onPlay: () => onPlay(entry.value),
                      onFavorite: () => onFavorite(entry.value),
                      onDownload: () => onDownload(entry.value),
                    ),
                  ),
                )),
        ],
      ),
    );
  }
}

class SettingsTab extends StatelessWidget {
  const SettingsTab({
    super.key,
    required this.email,
    required this.themeMode,
    required this.onThemeChanged,
    required this.onLogout,
  });

  final String email;
  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onThemeChanged;
  final VoidCallback onLogout;

  @override
  Widget build(BuildContext context) {
    final dark = themeMode == ThemeMode.dark;
    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 190),
        children: [
          const _HeaderBar(title: 'الإعدادات'),
          const SizedBox(height: 18),
          _GlassPanel(
            child: Row(
              children: [
                const CircleAvatar(radius: 28, backgroundImage: AssetImage('assets/images/sheikh_logo.jpg')),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('حساب التطبيق', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                      const SizedBox(height: 4),
                      Text(email.isEmpty ? 'زائر' : email, textDirection: TextDirection.ltr, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _SettingsTile(
            icon: dark ? Icons.dark_mode_rounded : Icons.light_mode_rounded,
            title: 'الوضع الداكن',
            subtitle: 'تغيير ألوان التطبيق لراحة العين.',
            trailing: Switch(value: dark, onChanged: (v) => onThemeChanged(v ? ThemeMode.dark : ThemeMode.light)),
          ),
          const SizedBox(height: 12),
          const _InfoStrip(
            icon: Icons.cloud_sync_rounded,
            title: 'التحديثات بدون APK',
            text: 'القائمة الصوتية تُسحب من الأرشيف عند فتح التطبيق. البنرات والإشعارات والرسائل يمكن ربطها لاحقًا بـ Firebase Remote Config.',
          ),
          const SizedBox(height: 12),
          const _InfoStrip(
            icon: Icons.download_rounded,
            title: 'التحميل',
            text: 'زر التحميل بجانب كل تلاوة يفتح رابط ملف الأرشيف مباشرة من المتصفح.',
          ),
          const SizedBox(height: 22),
          SizedBox(
            height: 54,
            child: OutlinedButton.icon(
              onPressed: onLogout,
              icon: const Icon(Icons.logout_rounded),
              label: const Text('تسجيل الخروج'),
            ),
          ),
        ],
      ),
    );
  }
}

class _HeaderBar extends StatelessWidget {
  const _HeaderBar({this.title = 'نوادر المنشاوي'});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _TopLogo(compact: true),
        const SizedBox(width: 14),
        Expanded(
          child: Text(title, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontSize: 27)),
        ),
        Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Theme.of(context).colorScheme.surface,
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(.05), blurRadius: 18, offset: const Offset(0, 8))],
          ),
          child: const Icon(Icons.more_horiz_rounded),
        ),
      ],
    );
  }
}

class _TopLogo extends StatelessWidget {
  const _TopLogo({required this.compact});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Hero(
      tag: 'app_logo',
      child: Container(
        width: compact ? 56 : 78,
        height: compact ? 56 : 78,
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Theme.of(context).colorScheme.surface,
          boxShadow: [BoxShadow(color: kPrimary.withOpacity(.15), blurRadius: 18, offset: const Offset(0, 9))],
        ),
        child: ClipOval(child: Image.asset('assets/images/app_logo.jpg', fit: BoxFit.cover)),
      ),
    );
  }
}

class HeroQuranCard extends StatelessWidget {
  const HeroQuranCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(34),
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Color(0xFFBAE8FF), Color(0xFFEAF8FF)],
        ),
        boxShadow: [BoxShadow(color: kPrimary.withOpacity(.16), blurRadius: 30, offset: const Offset(0, 16))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(color: Colors.white.withOpacity(.72), borderRadius: BorderRadius.circular(99)),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [Icon(Icons.auto_awesome_rounded, size: 16, color: kPrimary), SizedBox(width: 6), Text('اختيار اليوم', style: TextStyle(fontWeight: FontWeight.w900, color: kInk))],
                ),
              ),
              const Spacer(),
              const Icon(Icons.graphic_eq_rounded, color: kPrimary, size: 30),
            ],
          ),
          const SizedBox(height: 20),
          const Text(
            '﴿ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ ﴾',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 27, height: 1.95, fontWeight: FontWeight.w800, color: Color(0xFF1D8CC5)),
          ),
          const SizedBox(height: 10),
          const Text('سورة الرعد - الآية 28', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF506070))),
        ],
      ),
    );
  }
}

class StatsRow extends StatelessWidget {
  const StatsRow({super.key, required this.total, required this.favorites, required this.sections});

  final int total;
  final int favorites;
  final int sections;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: _StatCard(title: 'تلاوة', value: total.toString(), icon: Icons.library_music_rounded)),
        const SizedBox(width: 10),
        Expanded(child: _StatCard(title: 'قسم', value: sections.toString(), icon: Icons.grid_view_rounded)),
        const SizedBox(width: 10),
        Expanded(child: _StatCard(title: 'مفضلة', value: favorites.toString(), icon: Icons.favorite_rounded)),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.title, required this.value, required this.icon});

  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return _GlassPanel(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      child: Column(
        children: [
          Icon(icon, color: kPrimary),
          const SizedBox(height: 8),
          Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 22)),
          const SizedBox(height: 2),
          Text(title, style: TextStyle(color: cs.onSurfaceVariant, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class SectionsCarousel extends StatelessWidget {
  const SectionsCarousel({super.key, required this.sections, required this.selected, required this.onChanged});

  final List<String> sections;
  final String selected;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    if (sections.length <= 1) return const SizedBox.shrink();
    return SizedBox(
      height: 108,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: sections.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          final section = sections[index];
          final active = section == selected;
          return GestureDetector(
            onTap: () => onChanged(section),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 260),
              width: section == 'الكل' ? 118 : 190,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(26),
                gradient: active ? const LinearGradient(colors: [kPrimary, kSecondary], begin: Alignment.topRight, end: Alignment.bottomLeft) : null,
                color: active ? null : cs.surface,
                boxShadow: [BoxShadow(color: active ? kPrimary.withOpacity(.22) : Colors.black.withOpacity(.04), blurRadius: 20, offset: const Offset(0, 10))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(_sectionIcon(section), color: active ? Colors.white : kPrimary),
                  const Spacer(),
                  Text(
                    section,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontWeight: FontWeight.w900, color: active ? Colors.white : cs.onSurface, height: 1.2),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

IconData _sectionIcon(String section) {
  if (section == 'الكل') return Icons.auto_awesome_mosaic_rounded;
  if (section.contains('الحفلات') || section.contains('المحافل')) return Icons.mic_external_on_rounded;
  if (section.contains('فديو') || section.contains('فيديو')) return Icons.video_library_rounded;
  if (section.contains('المجود')) return Icons.record_voice_over_rounded;
  if (section.contains('المرتل')) return Icons.menu_book_rounded;
  return Icons.folder_special_rounded;
}

class TrackCard extends StatelessWidget {
  const TrackCard({
    super.key,
    required this.track,
    required this.isPlaying,
    required this.isFavorite,
    required this.onPlay,
    required this.onFavorite,
    required this.onDownload,
  });

  final ArchiveTrack track;
  final bool isPlaying;
  final bool isFavorite;
  final VoidCallback onPlay;
  final VoidCallback onFavorite;
  final VoidCallback onDownload;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(28),
        onTap: onPlay,
        child: Ink(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: cs.surface,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: isPlaying ? kPrimary.withOpacity(.35) : Colors.transparent, width: 1.2),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(.045), blurRadius: 20, offset: const Offset(0, 10))],
          ),
          child: Row(
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 240),
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: isPlaying
                      ? const LinearGradient(colors: [kPrimary, kSecondary])
                      : LinearGradient(colors: [kPrimary.withOpacity(.13), kSecondary.withOpacity(.16)]),
                ),
                child: Icon(isPlaying ? Icons.graphic_eq_rounded : Icons.play_arrow_rounded, color: isPlaying ? Colors.white : kPrimary, size: 30),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(track.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w900, height: 1.25)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      children: [
                        _MiniTag(icon: Icons.folder_rounded, text: track.shortSection),
                        if (track.sizeLabel.isNotEmpty) _MiniTag(icon: Icons.sd_storage_rounded, text: track.sizeLabel),
                        _MiniTag(icon: Icons.cloud_done_rounded, text: 'من الأرشيف'),
                      ],
                    ),
                  ],
                ),
              ),
              Column(
                children: [
                  IconButton(onPressed: onFavorite, icon: Icon(isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: isFavorite ? Colors.redAccent : cs.onSurfaceVariant)),
                  IconButton(onPressed: onDownload, icon: const Icon(Icons.download_rounded)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MiniTag extends StatelessWidget {
  const _MiniTag({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(color: kPrimary.withOpacity(.10), borderRadius: BorderRadius.circular(99)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: kPrimary),
          const SizedBox(width: 4),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 110),
            child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11.5, color: cs.onSurface, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }
}

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({
    super.key,
    required this.player,
    required this.track,
    required this.onPlayPause,
    required this.onNext,
    required this.onPrev,
  });

  final AudioPlayer player;
  final ArchiveTrack? track;
  final VoidCallback onPlayPause;
  final VoidCallback onNext;
  final VoidCallback onPrev;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return AnimatedSlide(
      duration: const Duration(milliseconds: 320),
      curve: Curves.easeOutCubic,
      offset: track == null ? const Offset(0, .25) : Offset.zero,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 280),
        opacity: track == null ? 0 : 1,
        child: track == null
            ? const SizedBox.shrink()
            : Padding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(28),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
                      decoration: BoxDecoration(
                        color: cs.surface.withOpacity(.90),
                        borderRadius: BorderRadius.circular(28),
                        border: Border.all(color: kPrimary.withOpacity(.16)),
                        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.10), blurRadius: 24, offset: const Offset(0, 14))],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 44,
                                height: 44,
                                decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [kPrimary, kSecondary])),
                                child: const Icon(Icons.graphic_eq_rounded, color: Colors.white),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(track!.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)),
                                    Text(track!.shortSection, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
                                  ],
                                ),
                              ),
                              IconButton(onPressed: onPrev, icon: const Icon(Icons.skip_previous_rounded)),
                              StreamBuilder<bool>(
                                stream: player.playingStream,
                                initialData: player.playing,
                                builder: (context, snapshot) {
                                  final playing = snapshot.data ?? false;
                                  return IconButton.filled(
                                    onPressed: onPlayPause,
                                    icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
                                  );
                                },
                              ),
                              IconButton(onPressed: onNext, icon: const Icon(Icons.skip_next_rounded)),
                            ],
                          ),
                          StreamBuilder<Duration>(
                            stream: player.positionStream,
                            builder: (context, posSnap) {
                              final pos = posSnap.data ?? Duration.zero;
                              final dur = player.duration ?? Duration.zero;
                              final maxMs = max(1, dur.inMilliseconds).toDouble();
                              final value = min(pos.inMilliseconds.toDouble(), maxMs);
                              return Slider(
                                value: value,
                                min: 0,
                                max: maxMs,
                                onChanged: (v) => player.seek(Duration(milliseconds: v.round())),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
      ),
    );
  }
}

class AppBottomBar extends StatelessWidget {
  const AppBottomBar({super.key, required this.currentIndex, required this.onTap});

  final int currentIndex;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    final items = const [
      _NavItem(Icons.home_rounded, 'الرئيسية'),
      _NavItem(Icons.library_music_rounded, 'المكتبة'),
      _NavItem(Icons.favorite_rounded, 'المفضلة'),
      _NavItem(Icons.settings_rounded, 'الإعدادات'),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Container(
            height: 74,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface.withOpacity(.92),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: kPrimary.withOpacity(.12)),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(.10), blurRadius: 25, offset: const Offset(0, 12))],
            ),
            child: Row(
              children: List.generate(items.length, (index) {
                final active = index == currentIndex;
                final item = items[index];
                return Expanded(
                  child: GestureDetector(
                    onTap: () => onTap(index),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 240),
                      curve: Curves.easeOutCubic,
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(22),
                        color: active ? kPrimary.withOpacity(.13) : Colors.transparent,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(item.icon, color: active ? kPrimary : Theme.of(context).colorScheme.onSurfaceVariant),
                          const SizedBox(height: 3),
                          Text(item.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w900, color: active ? kPrimary : Theme.of(context).colorScheme.onSurfaceVariant)),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem {
  const _NavItem(this.icon, this.label);
  final IconData icon;
  final String label;
}

class _GlassPanel extends StatelessWidget {
  const _GlassPanel({required this.child, this.padding = const EdgeInsets.all(18)});

  final Widget child;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface.withOpacity(.92),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: kPrimary.withOpacity(.10)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.045), blurRadius: 22, offset: const Offset(0, 12))],
      ),
      child: child,
    );
  }
}

class _InfoStrip extends StatelessWidget {
  const _InfoStrip({required this.icon, required this.title, required this.text});

  final IconData icon;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return _GlassPanel(
      padding: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(backgroundColor: kPrimary.withOpacity(.12), foregroundColor: kPrimary, child: Icon(icon)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 5),
                Text(text, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, height: 1.55)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  const _SettingsTile({required this.icon, required this.title, required this.subtitle, required this.trailing});

  final IconData icon;
  final String title;
  final String subtitle;
  final Widget trailing;

  @override
  Widget build(BuildContext context) {
    return _GlassPanel(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          CircleAvatar(backgroundColor: kPrimary.withOpacity(.12), foregroundColor: kPrimary, child: Icon(icon)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
              const SizedBox(height: 5),
              Text(subtitle, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ]),
          ),
          trailing,
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, this.action});

  final String title;
  final String? action;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 22)),
        const Spacer(),
        if (action != null) Text(action!, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontWeight: FontWeight.w800)),
      ],
    );
  }
}

class AnimatedListItem extends StatelessWidget {
  const AnimatedListItem({super.key, required this.index, required this.child});

  final int index;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 360 + ((index > 8 ? 8 : index) * 55)),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(offset: Offset(0, 18 * (1 - value)), child: child),
        );
      },
      child: child,
    );
  }
}

class TrackSkeleton extends StatelessWidget {
  const TrackSkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: .35, end: .75),
      duration: const Duration(milliseconds: 850),
      curve: Curves.easeInOut,
      builder: (context, value, _) {
        final color = Theme.of(context).colorScheme.onSurface.withOpacity(value * .12);
        return Container(
          height: 92,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(28)),
          child: Row(
            children: [
              Container(width: 56, height: 56, decoration: BoxDecoration(shape: BoxShape.circle, color: color)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Container(height: 14, width: double.infinity, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(99))),
                  const SizedBox(height: 12),
                  Container(height: 12, width: 150, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(99))),
                ]),
              ),
            ],
          ),
        );
      },
    );
  }
}

class ErrorCard extends StatelessWidget {
  const ErrorCard({super.key, required this.message, required this.onRetry});

  final String message;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    return EmptyState(
      icon: Icons.wifi_off_rounded,
      title: 'مشكلة في الاتصال',
      text: message,
      action: FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh_rounded), label: const Text('تحديث المكتبة')),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.title, required this.text, this.action});

  final IconData icon;
  final String title;
  final String text;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return _GlassPanel(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          Icon(icon, size: 56, color: kWarm),
          const SizedBox(height: 12),
          Text(title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text(text, textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, height: 1.6)),
          if (action != null) ...[const SizedBox(height: 16), action!],
        ],
      ),
    );
  }
}

class ArchiveTrack {
  const ArchiveTrack({
    required this.id,
    required this.fileName,
    required this.title,
    required this.section,
    required this.url,
    required this.size,
    required this.format,
  });

  final String id;
  final String fileName;
  final String title;
  final String section;
  final String url;
  final int size;
  final String format;

  String get shortSection {
    var s = section.replaceFirst(RegExp(r'^\d+\s*[-_،.]*\s*'), '').trim();
    if (s.isEmpty) s = 'تلاوات';
    return s;
  }

  String get sizeLabel {
    if (size <= 0) return '';
    final mb = size / (1024 * 1024);
    if (mb >= 1000) return '${(mb / 1024).toStringAsFixed(1)} جيجا';
    return '${mb.toStringAsFixed(mb >= 10 ? 0 : 1)} ميجا';
  }
}

class ArchiveRepository {
  Future<List<ArchiveTrack>> fetchTracks() async {
    final identifier = AppConfig.instance.archiveIdentifier;
    final uri = Uri.parse('https://archive.org/metadata/$identifier');
    final response = await http.get(uri).timeout(const Duration(seconds: 25));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Archive metadata failed');
    }

    final data = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final files = (data['files'] as List<dynamic>? ?? const []);
    final tracks = <ArchiveTrack>[];

    for (final item in files) {
      if (item is! Map<String, dynamic>) continue;
      final rawName = (item['name'] ?? '').toString();
      final name = Uri.decodeFull(rawName);
      if (!_isAudio(name)) continue;
      if (_isDerivedOrSystem(name)) continue;

      final section = _sectionFromPath(name);
      final title = _titleFromPath(name);
      final size = int.tryParse((item['size'] ?? '0').toString()) ?? 0;
      final format = (item['format'] ?? '').toString();
      final encoded = _encodePath(name);

      tracks.add(ArchiveTrack(
        id: name,
        fileName: name,
        title: title,
        section: section,
        url: 'https://archive.org/download/$identifier/$encoded',
        size: size,
        format: format,
      ));
    }

    tracks.sort((a, b) {
      final ac = _concertPriority(a.section);
      final bc = _concertPriority(b.section);
      if (ac != bc) return ac.compareTo(bc);
      return a.title.compareTo(b.title);
    });

    return tracks;
  }

  bool _isAudio(String name) {
    final lower = name.toLowerCase();
    return lower.endsWith('.mp3') || lower.endsWith('.m4a') || lower.endsWith('.aac') || lower.endsWith('.ogg') || lower.endsWith('.wav');
  }

  bool _isDerivedOrSystem(String name) {
    final lower = name.toLowerCase();
    return lower.contains('_files.xml') || lower.contains('_meta.xml') || lower.contains('__macosx') || lower.contains('/.') || lower.endsWith('.torrent');
  }

  int _concertPriority(String section) {
    if (section.contains('الحفلات') || section.contains('المحافل')) return 0;
    if (section.contains('الإذ') || section.contains('اذاع')) return 1;
    if (section.contains('المجود')) return 2;
    return 3;
  }

  String _sectionFromPath(String path) {
    final parts = path.split('/').where((e) => e.trim().isNotEmpty).toList();
    if (parts.length <= 1) return 'تلاوات متفرقة';
    return _clean(parts.first);
  }

  String _titleFromPath(String path) {
    final parts = path.split('/').where((e) => e.trim().isNotEmpty).toList();
    final file = parts.isEmpty ? path : parts.last;
    var title = _clean(file);
    title = title.replaceAll(RegExp(r'\.(mp3|m4a|aac|ogg|wav)$', caseSensitive: false), '');
    title = title.replaceAll(RegExp(r'^\d+\s*[-_،.]*\s*'), '');
    title = title.replaceAll('_', ' ');
    title = title.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (title.isEmpty) return 'تلاوة من الأرشيف';
    return title;
  }

  String _clean(String value) {
    return value.replaceAll('%20', ' ').replaceAll('_', ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  String _encodePath(String path) {
    return path.split('/').map(Uri.encodeComponent).join('/');
  }
}

extension WidgetListSpacing<T extends Widget> on List<T> {
  List<Widget> separatedBy(Widget separator) {
    if (isEmpty) return this;
    final result = <Widget>[];
    for (var i = 0; i < length; i++) {
      result.add(this[i]);
      if (i != length - 1) result.add(separator);
    }
    return result;
  }
}
