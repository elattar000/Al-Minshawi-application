import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_options.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

// ==========================================
// إدارة حالة تشغيل الصوت، المفضلة، ومؤقت النوم
// ==========================================
final AudioPlayer globalAudioPlayer = AudioPlayer();
final AudioPlayer globalPreloadAudioPlayer = AudioPlayer();
String? _lastPreloadedArchiveFile;

class PlaybackState {
  final String title;
  final String fileName;
  final List<Map<String, dynamic>> playlist;
  final int currentIndex;

  PlaybackState({
    required this.title,
    required this.fileName,
    required this.playlist,
    required this.currentIndex,
  });
}

final ValueNotifier<PlaybackState?> currentPlayback = ValueNotifier(null);
final ValueNotifier<List<String>> favoritesNotifier = ValueNotifier([]);

String buildArchiveAudioUrl(String fileName) {
  final encodedPath = fileName.split('/').map(Uri.encodeComponent).join('/');
  return 'https://archive.org/download/Encyclopedia-of-Alminshawi/$encodedPath';
}

Future<void> preloadArchiveAudio(String fileName) async {
  if (fileName.isEmpty || _lastPreloadedArchiveFile == fileName) return;
  _lastPreloadedArchiveFile = fileName;
  final uri = Uri.parse(buildArchiveAudioUrl(fileName));
  try {
    await globalPreloadAudioPlayer.setAudioSource(LockCachingAudioSource(uri), preload: true);
  } catch (_) {
    // التجهيز المسبق اختياري؛ لو فشل لا يؤثر على تشغيل التلاوة.
  }
}

void preloadNextArchiveTrack(List<Map<String, dynamic>> playlist, int currentIndex) {
  final nextIndex = currentIndex + 1;
  if (nextIndex >= 0 && nextIndex < playlist.length) {
    final nextFile = playlist[nextIndex]['name']?.toString() ?? '';
    if (nextFile.isNotEmpty) unawaited(preloadArchiveAudio(nextFile));
  }
}

Future<void> playArchiveAudio(String fileName) async {
  final uri = Uri.parse(buildArchiveAudioUrl(fileName));
  try {
    await globalAudioPlayer.setAudioSource(LockCachingAudioSource(uri), preload: true);
  } catch (_) {
    await globalAudioPlayer.setAudioSource(AudioSource.uri(uri), preload: true);
  }
  await globalAudioPlayer.play();
}

// إدارة مؤقت النوم
Timer? globalSleepTimer;
final ValueNotifier<int?> sleepTimerRemainingSeconds = ValueNotifier(null);

void startSleepTimer(int minutes) {
  globalSleepTimer?.cancel();
  if (minutes == 0) {
    sleepTimerRemainingSeconds.value = null;
    return;
  }
  int seconds = minutes * 60;
  sleepTimerRemainingSeconds.value = seconds;
  globalSleepTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
    if (sleepTimerRemainingSeconds.value != null && sleepTimerRemainingSeconds.value! > 0) {
      sleepTimerRemainingSeconds.value = sleepTimerRemainingSeconds.value! - 1;
    } else {
      globalAudioPlayer.pause();
      sleepTimerRemainingSeconds.value = null;
      timer.cancel();
    }
  });
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  
  // تحميل قائمة المفضلة المحفوظة
  final prefs = await SharedPreferences.getInstance();
  final favList = prefs.getStringList('favorites_list') ?? [];
  favoritesNotifier.value = favList;

  runApp(const MinshawiApp());
}

class MinshawiApp extends StatelessWidget {
  const MinshawiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'موسوعة الشيخ المنشاوي',
      
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('ar', 'AE'),
      ],
      locale: const Locale('ar', 'AE'),

      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
        primaryColor: const Color(0xFF168BD0),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF168BD0),
          primary: const Color(0xFF168BD0),
        ),
        textTheme: GoogleFonts.tajawalTextTheme(),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.white,
          elevation: 0,
          scrolledUnderElevation: 0,
          iconTheme: const IconThemeData(color: Color(0xFF1E293B)),
          titleTextStyle: GoogleFonts.tajawal(
            color: const Color(0xFF1E293B),
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

// ==========================================
// 1. شاشة اللودنج (Splash Screen)
// ==========================================
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1800), () {
      final user = FirebaseAuth.instance.currentUser;
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => user != null ? const MainLayout() : const LoginScreen(),
          transitionsBuilder: (_, animation, __, child) => FadeTransition(opacity: animation, child: child),
          transitionDuration: const Duration(milliseconds: 450),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFFF7FBFF),
      body: SafeArea(
        child: ProfessionalLoader(message: 'جاري تجهيز موسوعة الشيخ المنشاوي'),
      ),
    );
  }
}

class ProfessionalLoader extends StatelessWidget {
  final String message;
  const ProfessionalLoader({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 122,
            height: 122,
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFF168BD0), Color(0xFF62C8FF)],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF168BD0).withOpacity(0.18),
                  blurRadius: 26,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            child: ClipOval(
              child: Image.asset('assets/images/app_logo.jpg', fit: BoxFit.cover),
            ),
          ).animate().fade(duration: 450.ms).scale(begin: const Offset(0.82, 0.82), curve: Curves.easeOutBack),
          const SizedBox(height: 26),
          Text(
            message,
            textAlign: TextAlign.center,
            style: GoogleFonts.tajawal(
              color: const Color(0xFF0F5E9C),
              fontSize: 17,
              fontWeight: FontWeight.w800,
            ),
          ).animate().fade(delay: 150.ms).slideY(begin: 0.08),
          const SizedBox(height: 18),
          const LoadingDots(),
        ],
      ),
    );
  }
}

class LoadingDots extends StatelessWidget {
  const LoadingDots({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(3, (index) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 5),
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: const Color(0xFF168BD0).withOpacity(0.95),
            shape: BoxShape.circle,
          ),
        )
            .animate(onPlay: (controller) => controller.repeat(reverse: true))
            .scale(
              delay: (index * 150).ms,
              duration: 550.ms,
              begin: const Offset(0.65, 0.65),
              end: const Offset(1.25, 1.25),
              curve: Curves.easeInOut,
            )
            .fade(begin: 0.45, end: 1);
      }),
    );
  }
}

class CenterMessageDialog extends StatelessWidget {
  final String message;
  final bool error;
  const CenterMessageDialog({super.key, required this.message, required this.error});

  @override
  Widget build(BuildContext context) {
    final color = error ? const Color(0xFFE53935) : const Color(0xFF168BD0);
    final icon = error ? Icons.error_outline_rounded : Icons.check_circle_outline_rounded;

    return Center(
      child: Material(
        color: Colors.transparent,
        child: Container(
          width: MediaQuery.of(context).size.width * 0.82,
          padding: const EdgeInsets.fromLTRB(22, 24, 22, 18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(26),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.18),
                blurRadius: 34,
                offset: const Offset(0, 18),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 62,
                height: 62,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.10),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: color, size: 36),
              ).animate().scale(duration: 350.ms, curve: Curves.easeOutBack),
              const SizedBox(height: 12),
              Text(
                message,
                textAlign: TextAlign.center,
                style: GoogleFonts.tajawal(
                  color: const Color(0xFF1E293B),
                  fontSize: 16,
                  height: 1.45,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                height: 44,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    elevation: 0,
                    backgroundColor: color,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  onPressed: () => Navigator.of(context, rootNavigator: true).pop(),
                  child: Text('تمام', style: GoogleFonts.tajawal(fontWeight: FontWeight.w800, fontSize: 16)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// 2. شاشة الدخول المباشرة المدمجة والاحترافية
// ==========================================
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  bool _isLoading = false;
  bool _isSignUp = false;
  bool _showPassword = false;
  bool _showConfirmPassword = false;

  static const Color _blue = Color(0xFF168BD0);
  static const Color _deepBlue = Color(0xFF0F5E9C);

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _showMessage(String message, {bool error = true}) {
    if (!mounted) return;
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'message',
      barrierColor: Colors.black.withOpacity(0.22),
      transitionDuration: const Duration(milliseconds: 260),
      pageBuilder: (_, __, ___) => CenterMessageDialog(message: message, error: error),
      transitionBuilder: (_, animation, __, child) {
        return FadeTransition(
          opacity: animation,
          child: ScaleTransition(
            scale: CurvedAnimation(parent: animation, curve: Curves.easeOutBack),
            child: child,
          ),
        );
      },
    );
  }

  String _authErrorMessage(FirebaseAuthException e) {
    switch (e.code) {
      case 'wrong-password':
      case 'invalid-credential':
        return 'البريد الإلكتروني أو كلمة المرور غير صحيحة';
      case 'user-not-found':
        return 'لا يوجد حساب بهذا البريد الإلكتروني';
      case 'email-already-in-use':
        return 'هذا البريد مستخدم بالفعل، سجل دخولك بدلاً من إنشاء حساب جديد';
      case 'weak-password':
        return 'كلمة المرور ضعيفة، اكتب 6 أحرف على الأقل';
      case 'invalid-email':
        return 'صيغة البريد الإلكتروني غير صحيحة';
      case 'network-request-failed':
        return 'تأكد من اتصال الإنترنت ثم حاول مرة أخرى';
      default:
        return e.message ?? 'حدث خطأ في المصادقة';
    }
  }

  Future<void> _authenticate() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();
    final name = _nameController.text.trim();
    final confirmPassword = _confirmPasswordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      _showMessage('اكتب البريد الإلكتروني وكلمة المرور');
      return;
    }

    if (_isSignUp) {
      if (name.isEmpty) {
        _showMessage('اكتب الاسم');
        return;
      }
      if (password != confirmPassword) {
        _showMessage('كلمة المرور غير متطابقة');
        return;
      }
      if (password.length < 6) {
        _showMessage('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
        return;
      }
    }

    setState(() => _isLoading = true);
    try {
      if (_isSignUp) {
        final credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email,
          password: password,
        );
        await credential.user?.updateDisplayName(name);
        await credential.user?.sendEmailVerification();
        await FirebaseAuth.instance.signOut();

        if (!mounted) return;
        _showMessage('تم إنشاء الحساب وإرسال رابط تأكيد البريد الإلكتروني. افتح بريدك واضغط على رابط التأكيد ثم سجل دخولك.', error: false);
        setState(() {
          _isSignUp = false;
          _passwordController.clear();
          _confirmPasswordController.clear();
        });
        return;
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email,
          password: password,
        );

        await FirebaseAuth.instance.currentUser?.reload();
        final user = FirebaseAuth.instance.currentUser;
        if (user != null && !user.emailVerified) {
          await user.sendEmailVerification();
          await FirebaseAuth.instance.signOut();
          if (!mounted) return;
          _showMessage('يجب تأكيد البريد الإلكتروني أولاً. أرسلنا لك رابط التأكيد مرة أخرى.', error: false);
          return;
        }
      }

      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainLayout()));
    } on FirebaseAuthException catch (e) {
      _showMessage(_authErrorMessage(e));
    } catch (_) {
      _showMessage('حدث خطأ غير متوقع');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _resetPassword() async {
    final email = _emailController.text.trim();
    if (email.isEmpty) {
      _showMessage('اكتب البريد الإلكتروني أولاً');
      return;
    }

    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
      if (!mounted) return;
      _showMessage('تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني', error: false);
    } on FirebaseAuthException catch (e) {
      _showMessage(e.message ?? 'تعذر إرسال رابط استعادة كلمة المرور');
    }
  }

  void _continueAsGuest() {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainLayout()));
  }

  void _switchMode() {
    FocusScope.of(context).unfocus();
    setState(() {
      _isSignUp = !_isSignUp;
      _confirmPasswordController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7FBFF),
      body: Stack(
        children: [
          Positioned(
            top: -120,
            right: -120,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _blue.withOpacity(0.10),
              ),
            ),
          ),
          Positioned(
            bottom: -150,
            left: -130,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _blue.withOpacity(0.08),
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(24, 14, 24, 16),
                child: AnimatedSwitcher(
                  duration: 350.ms,
                  switchInCurve: Curves.easeOutCubic,
                  switchOutCurve: Curves.easeInCubic,
                  transitionBuilder: (child, animation) {
                    final offsetAnimation = Tween<Offset>(
                      begin: const Offset(0, 0.04),
                      end: Offset.zero,
                    ).animate(animation);
                    return FadeTransition(
                      opacity: animation,
                      child: SlideTransition(position: offsetAnimation, child: child),
                    );
                  },
                  child: _isSignUp ? _buildSignUpView() : _buildLoginView(),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoginView() {
    return Column(
      key: const ValueKey('login'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildLogoHeader('تسجيل دخول', 'سجل دخول للوصول لحسابك'),
        const SizedBox(height: 26),
        _buildField(
          controller: _emailController,
          hint: 'البريد الإلكتروني',
          icon: Icons.alternate_email_rounded,
          keyboardType: TextInputType.emailAddress,
        ).animate().fade(delay: 120.ms).slideX(begin: 0.08),
        const SizedBox(height: 12),
        _buildField(
          controller: _passwordController,
          hint: 'كلمة المرور',
          icon: Icons.lock_rounded,
          obscureText: !_showPassword,
          suffixIcon: IconButton(
            icon: Icon(_showPassword ? Icons.visibility_rounded : Icons.visibility_off_rounded, color: Colors.grey[500]),
            onPressed: () => setState(() => _showPassword = !_showPassword),
          ),
        ).animate().fade(delay: 190.ms).slideX(begin: 0.08),
        const SizedBox(height: 10),
        Align(
          alignment: Alignment.centerRight,
          child: TextButton(
            onPressed: _resetPassword,
            style: TextButton.styleFrom(padding: EdgeInsets.zero),
            child: Text(
              'نسيت كلمة المرور؟',
              style: GoogleFonts.tajawal(color: _blue, fontSize: 15, fontWeight: FontWeight.bold),
            ),
          ),
        ).animate().fade(delay: 240.ms),
        const SizedBox(height: 26),
        _buildMainButton('تسجيل دخول').animate().fade(delay: 290.ms).scale(begin: const Offset(0.96, 0.96)),
        const SizedBox(height: 22),
        TextButton(
          onPressed: _continueAsGuest,
          child: Text(
            'تصفح كزائر',
            style: GoogleFonts.tajawal(color: Colors.grey[600], fontSize: 17, fontWeight: FontWeight.w600),
          ),
        ).animate().fade(delay: 340.ms),
        const SizedBox(height: 12),
        _buildSwitchRow('ليس لديك حساب؟', 'سجل الآن').animate().fade(delay: 390.ms),
      ],
    );
  }

  Widget _buildSignUpView() {
    return Column(
      key: const ValueKey('signup'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildLogoHeader('اعمل حساب', 'أنشئ حسابك الجديد'),
        const SizedBox(height: 26),
        _buildField(
          controller: _nameController,
          hint: 'الاسم',
          icon: Icons.person_outline_rounded,
          keyboardType: TextInputType.name,
        ).animate().fade(delay: 100.ms).slideX(begin: 0.08),
        const SizedBox(height: 12),
        _buildField(
          controller: _emailController,
          hint: 'البريد الإلكتروني',
          icon: Icons.alternate_email_rounded,
          keyboardType: TextInputType.emailAddress,
        ).animate().fade(delay: 160.ms).slideX(begin: 0.08),
        const SizedBox(height: 12),
        _buildField(
          controller: _passwordController,
          hint: 'كلمة المرور',
          icon: Icons.lock_outline_rounded,
          obscureText: !_showPassword,
          suffixIcon: IconButton(
            icon: Icon(_showPassword ? Icons.visibility_rounded : Icons.visibility_off_rounded, color: Colors.grey[500]),
            onPressed: () => setState(() => _showPassword = !_showPassword),
          ),
        ).animate().fade(delay: 220.ms).slideX(begin: 0.08),
        const SizedBox(height: 12),
        _buildField(
          controller: _confirmPasswordController,
          hint: 'تأكيد كلمة المرور',
          icon: Icons.verified_user_outlined,
          obscureText: !_showConfirmPassword,
          suffixIcon: IconButton(
            icon: Icon(_showConfirmPassword ? Icons.visibility_rounded : Icons.visibility_off_rounded, color: Colors.grey[500]),
            onPressed: () => setState(() => _showConfirmPassword = !_showConfirmPassword),
          ),
        ).animate().fade(delay: 280.ms).slideX(begin: 0.08),
        const SizedBox(height: 26),
        _buildMainButton('اعمل حساب').animate().fade(delay: 340.ms).scale(begin: const Offset(0.96, 0.96)),
        const SizedBox(height: 22),
        _buildSwitchRow('لديك حساب بالفعل؟', 'سجل دخول الآن').animate().fade(delay: 390.ms),
      ],
    );
  }

  Widget _buildLogoHeader(String title, String subtitle) {
    return Column(
      children: [
        Container(
          width: 130,
          height: 130,
          padding: const EdgeInsets.all(5),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white,
            border: Border.all(color: _blue.withOpacity(0.20), width: 2),
          ),
          child: ClipOval(
            child: Image.asset('assets/images/app_logo.jpg', fit: BoxFit.cover),
          ),
        ).animate().fade(duration: 450.ms).scale(begin: const Offset(0.86, 0.86), curve: Curves.easeOutBack),
        const SizedBox(height: 18),
        Text(
          title,
          textAlign: TextAlign.center,
          style: GoogleFonts.tajawal(
            color: _blue,
            fontSize: 40,
            height: 1,
            fontWeight: FontWeight.w900,
          ),
        ).animate().fade(delay: 80.ms).slideY(begin: 0.08),
        const SizedBox(height: 10),
        Text(
          subtitle,
          textAlign: TextAlign.center,
          style: GoogleFonts.tajawal(
            color: const Color(0xFF263238),
            fontSize: 17,
            fontWeight: FontWeight.w600,
          ),
        ).animate().fade(delay: 120.ms).slideY(begin: 0.08),
      ],
    );
  }

  Widget _buildField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    TextInputType? keyboardType,
    bool obscureText = false,
    Widget? suffixIcon,
  }) {
    return Container(
      height: 62,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: _blue.withOpacity(0.055),
            blurRadius: 18,
            offset: const Offset(0, 9),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        obscureText: obscureText,
        textInputAction: TextInputAction.next,
        style: GoogleFonts.tajawal(fontSize: 18, color: const Color(0xFF1E293B), fontWeight: FontWeight.w600),
        decoration: InputDecoration(
          labelText: hint,
          floatingLabelBehavior: FloatingLabelBehavior.auto,
          labelStyle: GoogleFonts.tajawal(fontSize: 18, color: Colors.grey[500], fontWeight: FontWeight.w500),
          floatingLabelStyle: GoogleFonts.tajawal(fontSize: 15, color: _blue, fontWeight: FontWeight.w800),
          prefixIcon: Icon(icon, color: Colors.grey[500], size: 26),
          suffixIcon: suffixIcon,
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: Color(0xFFE2E8F0), width: 1.25),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: _blue, width: 2.0),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: Color(0xFFE53935), width: 1.5),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: Color(0xFFE2E8F0), width: 1.25),
          ),
        ),
      ),
    );
  }

  Widget _buildMainButton(String text) {
    return SizedBox(
      width: double.infinity,
      height: 60,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          elevation: 0,
          backgroundColor: _blue,
          foregroundColor: Colors.white,
          disabledBackgroundColor: _blue.withOpacity(0.55),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        onPressed: _isLoading ? null : _authenticate,
        child: _isLoading
            ? const SizedBox(
                width: 26,
                height: 26,
                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.6),
              )
            : Text(
                text,
                style: GoogleFonts.tajawal(fontSize: 21, fontWeight: FontWeight.w800, color: Colors.white),
              ),
      ),
    );
  }

  Widget _buildSwitchRow(String normalText, String actionText) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          normalText,
          style: GoogleFonts.tajawal(fontSize: 17, color: const Color(0xFF263238), fontWeight: FontWeight.w500),
        ),
        const SizedBox(width: 8),
        InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: _switchMode,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
            child: Text(
              actionText,
              style: GoogleFonts.tajawal(fontSize: 18, color: _blue, fontWeight: FontWeight.w800),
            ),
          ),
        ),
      ],
    );
  }
}


// ==========================================
// 3. الهيكل الرئيسي (شريط الأدوات السفلي الفخم والمشغل)
// ==========================================
class MainLayout extends StatefulWidget {
  const MainLayout({super.key});
  @override
  State<MainLayout> createState() => _MainLayoutState();
}

class _MainLayoutState extends State<MainLayout> {
  int _currentIndex = 0;
  final List<Widget> _pages = [
    const HomeScreen(),
    const FavoritesScreen(),
    const ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(child: _pages[_currentIndex]),
          _buildPersistentPlayer(),
        ],
      ),
      bottomNavigationBar: NavigationBarTheme(
        data: NavigationBarThemeData(
          indicatorColor: const Color(0xFF168BD0).withOpacity(0.15),
          iconTheme: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.selected)) {
              return const IconThemeData(color: Color(0xFF168BD0));
            }
            return const IconThemeData(color: Colors.grey);
          }),
          labelTextStyle: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.selected)) {
              return GoogleFonts.tajawal(fontWeight: FontWeight.bold, fontSize: 13, color: const Color(0xFF168BD0));
            }
            return GoogleFonts.tajawal(fontSize: 12, color: Colors.grey);
          }),
        ),
        child: NavigationBar(
          selectedIndex: _currentIndex,
          onDestinationSelected: (index) => setState(() => _currentIndex = index),
          backgroundColor: Colors.white,
          elevation: 10,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_filled), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.favorite), label: 'المفضلة'),
            NavigationDestination(icon: Icon(Icons.settings), label: 'حسابي'),
          ],
        ),
      ),
    );
  }

  Widget _buildPersistentPlayer() {
    return ValueListenableBuilder<PlaybackState?>(
      valueListenable: currentPlayback,
      builder: (context, playback, child) {
        if (playback == null) return const SizedBox.shrink();
        
        return GestureDetector(
          onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const DetailedPlayerScreen()));
          },
          child: Container(
            margin: const EdgeInsets.only(left: 12, right: 12, bottom: 8, top: 4),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFF1E293B),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 10, offset: const Offset(0, 4))],
            ),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.asset('assets/images/sheikh_logo.jpg', width: 48, height: 48, fit: BoxFit.cover),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        playback.title,
                        style: GoogleFonts.tajawal(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.white),
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        'الشيخ محمد صديق المنشاوي',
                        style: GoogleFonts.tajawal(color: Colors.grey[400], fontSize: 12),
                      ),
                    ],
                  ),
                ),
                StreamBuilder<PlayerState>(
                  stream: globalAudioPlayer.playerStateStream,
                  builder: (context, snapshot) {
                    final playing = snapshot.data?.playing ?? false;
                    final processingState = snapshot.data?.processingState;
                    
                    return IconButton(
                      icon: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_fill),
                      iconSize: 45,
                      color: Colors.white,
                      onPressed: () => playing ? globalAudioPlayer.pause() : globalAudioPlayer.play(),
                    );
                  },
                ),
              ],
            ),
          ),
        ).animate().slideY(begin: 1.0, duration: 300.ms);
      },
    );
  }
}

// ==========================================
// 4. دالة الـ Cache (تحميل مرة واحدة فقط)
// ==========================================
class ArchiveCacheService {
  static Future<List<dynamic>> getCachedOrFetchData({bool forceRefresh = false}) async {
    final prefs = await SharedPreferences.getInstance();
    final cachedJson = prefs.getString('archive_data_cache_v1');

    if (cachedJson != null && !forceRefresh) {
      return json.decode(cachedJson) as List;
    }

    try {
      final url = Uri.parse('https://archive.org/metadata/Encyclopedia-of-Alminshawi');
      final response = await http.get(url).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        final files = json.decode(response.body)['files'] as List;
        final mp3Files = files.where((file) => file['name'].toString().endsWith('.mp3')).toList();
        await prefs.setString('archive_data_cache_v1', json.encode(mp3Files));
        return mp3Files;
      } else {
        throw Exception('خطأ في السيرفر');
      }
    } catch (e) {
      if (cachedJson != null) {
        return json.decode(cachedJson) as List;
      }
      rethrow;
    }
  }
}

// ==========================================
// 5. الشاشة الرئيسية (أقسام بكروت فخمة عمودية وبحث ذكي شامل)
// ==========================================
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, List<Map<String, dynamic>>> _folders = {};
  List<Map<String, dynamic>> _allFlatTracks = [];
  List<Map<String, dynamic>> _searchResults = [];
  bool _isLoading = true;
  String _errorMsg = '';
  final _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData({bool forceRefresh = false}) async {
    setState(() { _isLoading = true; _errorMsg = ''; });
    try {
      final files = await ArchiveCacheService.getCachedOrFetchData(forceRefresh: forceRefresh);
      Map<String, List<Map<String, dynamic>>> tempFolders = {};
      List<Map<String, dynamic>> tempFlatTracks = [];

      for (var file in files) {
        String fileName = file['name'] ?? '';
        String folderName = fileName.contains('/') ? fileName.split('/')[0] : (fileName.contains('-') ? fileName.split('-')[0] : "تلاوات أخرى");
        
        final trackItem = Map<String, dynamic>.from(file);
        tempFolders.putIfAbsent(folderName, () => []).add(trackItem);
        tempFlatTracks.add(trackItem);
      }
      setState(() { 
        _folders = tempFolders; 
        _allFlatTracks = tempFlatTracks;
        _isLoading = false; 
      });
      if (tempFlatTracks.isNotEmpty) {
        unawaited(preloadArchiveAudio(tempFlatTracks.first['name']?.toString() ?? ''));
      }
    } catch (e) {
      setState(() { _errorMsg = 'تأكد من اتصالك بالإنترنت لتنزيل المكتبة لأول مرة.'; _isLoading = false; });
    }
  }

  void _onSearch(String query) {
    setState(() {
      _searchQuery = query.trim();
      if (_searchQuery.isEmpty) {
        _searchResults = [];
      } else {
        _searchResults = _allFlatTracks.where((track) {
          final title = track['name'].toString().split('/').last.replaceAll('.mp3', '').replaceAll('-', ' ').toLowerCase();
          return title.contains(_searchQuery.toLowerCase());
        }).toList();
      }
    });
  }

  void _playSearchedTrack(int index) async {
    final track = _searchResults[index];
    String fileName = track['name'];
    String cleanName = fileName.split('/').last.replaceAll('.mp3', '').replaceAll('-', ' ');
    
    currentPlayback.value = PlaybackState(
      title: cleanName,
      fileName: fileName,
      playlist: _searchResults,
      currentIndex: index,
    );

    Navigator.push(context, MaterialPageRoute(builder: (_) => const DetailedPlayerScreen()));
    unawaited(playArchiveAudio(fileName));
    preloadNextArchiveTrack(_searchResults, index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(
          children: [
            const SizedBox(width: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset('assets/images/app_logo.jpg', width: 40, height: 40),
            ),
            const SizedBox(width: 12),
            Text('موسوعة الشيخ المنشاوي', style: GoogleFonts.tajawal(fontWeight: FontWeight.bold, color: const Color(0xFF168BD0))),
          ],
        ),
      ),
      body: _isLoading
          ? const ProfessionalLoader(message: 'جاري تحميل المكتبة')
          : Column(
              children: [
                // شريط البحث الذكي الشامل الفخم
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: TextField(
                    controller: _searchController,
                    onChanged: _onSearch,
                    decoration: InputDecoration(
                      hintText: 'البحث عن تلاوة (سورة، محفل...)...',
                      prefixIcon: const Icon(Icons.search_rounded, color: Color(0xFF168BD0)),
                      suffixIcon: _searchQuery.isNotEmpty 
                          ? IconButton(
                              icon: const Icon(Icons.clear_rounded, color: Colors.grey),
                              onPressed: () { _searchController.clear(); _onSearch(''); },
                            )
                          : null,
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                    ),
                  ),
                ),
                
                Expanded(
                  child: _errorMsg.isNotEmpty
                      ? _buildErrorWidget()
                      : _searchQuery.isNotEmpty
                          ? _buildSearchResultsList()
                          : _buildFoldersList(),
                ),
              ],
            ),
    );
  }

  Widget _buildFoldersList() {
    return ListView.builder(
      padding: const EdgeInsets.only(left: 16, right: 16, bottom: 100),
      itemCount: _folders.keys.length,
      itemBuilder: (context, index) {
        String folderName = _folders.keys.elementAt(index);
        int count = _folders[folderName]!.length;

        return GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TracksScreen(folderName: folderName, tracks: _folders[folderName]!))),
          child: Container(
            margin: const EdgeInsets.only(bottom: 16),
            height: 100,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4))],
            ),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.only(topRight: Radius.circular(16), bottomRight: Radius.circular(16)),
                  child: Image.asset('assets/images/sheikh_logo.jpg', width: 100, height: 100, fit: BoxFit.cover),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(folderName, style: GoogleFonts.tajawal(fontSize: 16, fontWeight: FontWeight.bold), maxLines: 2, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 4),
                      Text('$count تلاوة خاشعة', style: GoogleFonts.tajawal(color: const Color(0xFF168BD0), fontSize: 13, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
                )
              ],
            ),
          ).animate().fade(delay: (50 * index).ms).slideX(begin: 0.1),
        );
      },
    );
  }

  Widget _buildSearchResultsList() {
    if (_searchResults.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.search_off_rounded, size: 64, color: Colors.grey),
            const SizedBox(height: 12),
            Text('لا توجد تلاوات مطابقة للبحث', style: GoogleFonts.tajawal(color: Colors.grey)),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.only(left: 16, right: 16, bottom: 100),
      itemCount: _searchResults.length,
      itemBuilder: (context, index) {
        String fileName = _searchResults[index]['name'];
        String cleanName = fileName.split('/').last.replaceAll('.mp3', '');

        return ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: const Color(0xFFF0F9FA), borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.play_arrow_rounded, color: Color(0xFF168BD0)),
          ),
          title: Text(cleanName, style: GoogleFonts.tajawal(fontWeight: FontWeight.bold, fontSize: 14)),
          onTap: () => _playSearchedTrack(index),
        ).animate().fade();
      },
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.wifi_off_rounded, size: 72, color: Colors.grey),
            const SizedBox(height: 12),
            Text(_errorMsg, textAlign: TextAlign.center, style: GoogleFonts.tajawal(fontSize: 15, color: Colors.grey[700])),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => _loadData(forceRefresh: true),
              child: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 6. قائمة التلاوات داخل القسم
// ==========================================
class TracksScreen extends StatelessWidget {
  final String folderName;
  final List<Map<String, dynamic>> tracks;

  const TracksScreen({super.key, required this.folderName, required this.tracks});

  void _playTrack(BuildContext context, int index) async {
    final track = tracks[index];
    String fileName = track['name'];
    String cleanName = fileName.split('/').last.replaceAll('.mp3', '').replaceAll('-', ' ');
    
    currentPlayback.value = PlaybackState(
      title: cleanName,
      fileName: fileName,
      playlist: tracks,
      currentIndex: index,
    );

    Navigator.push(context, MaterialPageRoute(builder: (_) => const DetailedPlayerScreen()));

    unawaited(playArchiveAudio(fileName));
    preloadNextArchiveTrack(tracks, index);
  }

  void _toggleFavorite(BuildContext context, String fileName) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> currentFavs = List.from(favoritesNotifier.value);
    if (currentFavs.contains(fileName)) {
      currentFavs.remove(fileName);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تمت الإزالة من المفضلة'), duration: Duration(seconds: 1)));
    } else {
      currentFavs.add(fileName);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم الإضافة إلى المفضلة'), duration: Duration(seconds: 1)));
    }
    await prefs.setStringList('favorites_list', currentFavs);
    favoritesNotifier.value = currentFavs;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(folderName, style: const TextStyle(fontSize: 18))),
      body: ValueListenableBuilder<List<String>>(
        valueListenable: favoritesNotifier,
        builder: (context, favs, child) {
          return ListView.builder(
            padding: const EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 100),
            itemCount: tracks.length,
            itemBuilder: (context, index) {
              String fileName = tracks[index]['name'];
              String cleanName = fileName.split('/').last.replaceAll('.mp3', '');
              bool isFavorite = favs.contains(fileName);

              return ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: const Color(0xFFF0F9FA), borderRadius: BorderRadius.circular(12)),
                  child: const Icon(Icons.play_arrow_rounded, color: Color(0xFF168BD0)),
                ),
                title: Text(cleanName, style: GoogleFonts.tajawal(fontWeight: FontWeight.bold, fontSize: 14)),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: Colors.red),
                      onPressed: () => _toggleFavorite(context, fileName),
                    ),
                    const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: Colors.grey),
                  ],
                ),
                onTap: () => _playTrack(context, index),
              ).animate().fade();
            },
          );
        },
      ),
    );
  }
}

// ==========================================
// 7. شاشة المفضلة (تعمل بالكامل أوفلاين وسريعة جداً)
// ==========================================
class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  void _playTrack(BuildContext context, int index, List<Map<String, dynamic>> playlist) async {
    final track = playlist[index];
    String fileName = track['name'];
    String cleanName = fileName.split('/').last.replaceAll('.mp3', '').replaceAll('-', ' ');
    
    currentPlayback.value = PlaybackState(
      title: cleanName,
      fileName: fileName,
      playlist: playlist,
      currentIndex: index,
    );

    Navigator.push(context, MaterialPageRoute(builder: (_) => const DetailedPlayerScreen()));

    unawaited(playArchiveAudio(fileName));
    preloadNextArchiveTrack(playlist, index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المفضلة')),
      body: ValueListenableBuilder<List<String>>(
        valueListenable: favoritesNotifier,
        builder: (context, favs, child) {
          if (favs.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.favorite_border_rounded, size: 72, color: Colors.grey),
                  const SizedBox(height: 12),
                  Text('لا توجد تلاوات مفضلة بعد', style: GoogleFonts.tajawal(fontSize: 16, color: Colors.grey)),
                ],
              ),
            );
          }

          List<Map<String, dynamic>> favTracks = favs.map((fileName) => {'name': fileName}).toList();

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: favTracks.length,
            itemBuilder: (context, index) {
              String fileName = favTracks[index]['name'];
              String cleanName = fileName.split('/').last.replaceAll('.mp3', '');

              return ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: const Color(0xFFFFF1F2), borderRadius: BorderRadius.circular(12)),
                  child: const Icon(Icons.favorite_rounded, color: Colors.red),
                ),
                title: Text(cleanName, style: GoogleFonts.tajawal(fontWeight: FontWeight.bold, fontSize: 14)),
                trailing: const Icon(Icons.play_circle_outline_rounded, color: Color(0xFF168BD0), size: 28),
                onTap: () => _playTrack(context, index, favTracks),
              ).animate().fade();
            },
          );
        },
      ),
    );
  }
}

// ==========================================
// 8. صفحة المشغل المستقلة والفخمة مع ميزة مؤقت النوم (Sleep Timer)
// ==========================================
class DetailedPlayerScreen extends StatelessWidget {
  const DetailedPlayerScreen({super.key});

  void _playNext() {
    final state = currentPlayback.value;
    if (state == null) return;
    int nextIndex = state.currentIndex + 1;
    if (nextIndex < state.playlist.length) {
      _playFromPlaylist(state.playlist, nextIndex);
    }
  }

  void _playPrevious() {
    final state = currentPlayback.value;
    if (state == null) return;
    int prevIndex = state.currentIndex - 1;
    if (prevIndex >= 0) {
      _playFromPlaylist(state.playlist, prevIndex);
    }
  }

  void _playFromPlaylist(List<Map<String, dynamic>> playlist, int index) async {
    final track = playlist[index];
    String fileName = track['name'];
    String cleanName = fileName.split('/').last.replaceAll('.mp3', '').replaceAll('-', ' ');
    
    currentPlayback.value = PlaybackState(
      title: cleanName,
      fileName: fileName,
      playlist: playlist,
      currentIndex: index,
    );

    unawaited(playArchiveAudio(fileName));
    preloadNextArchiveTrack(playlist, index);
  }

  void _showSleepTimerDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text('مؤقت النوم لإيقاف الصوت تلقائياً', style: GoogleFonts.tajawal(fontWeight: FontWeight.bold, fontSize: 16)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildTimerOption(context, 'إيقاف المؤقت', 0),
              _buildTimerOption(context, 'بعد 15 دقيقة', 15),
              _buildTimerOption(context, 'بعد 30 دقيقة', 30),
              _buildTimerOption(context, 'بعد 60 دقيقة', 60),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTimerOption(BuildContext context, String title, int minutes) {
    return ListTile(
      title: Text(title, style: GoogleFonts.tajawal()),
      onTap: () {
        startSleepTimer(minutes);
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(minutes == 0 ? 'تم إلغاء مؤقت النوم' : 'سيتم إيقاف التلاوة بعد $minutes دقيقة'), duration: const Duration(seconds: 2)),
        );
      },
    );
  }

  String _formatTimerSeconds(int totalSeconds) {
    int minutes = totalSeconds ~/ 60;
    int seconds = totalSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<PlaybackState?>(
      valueListenable: currentPlayback,
      builder: (context, playback, child) {
        if (playback == null) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }

        return Scaffold(
          backgroundColor: const Color(0xFF0F172A),
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: IconButton(
              icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white, size: 36),
              onPressed: () => Navigator.pop(context),
            ),
            actions: [
              // مؤقت النوم مع عد تنازلي حي
              ValueListenableBuilder<int?>(
                valueListenable: sleepTimerRemainingSeconds,
                builder: (context, secondsRemaining, child) {
                  return TextButton.icon(
                    onPressed: () => _showSleepTimerDialog(context),
                    icon: Icon(
                      secondsRemaining != null ? Icons.timer_rounded : Icons.timer_outlined,
                      color: secondsRemaining != null ? const Color(0xFF168BD0) : Colors.white70,
                    ),
                    label: Text(
                      secondsRemaining != null ? _formatTimerSeconds(secondsRemaining) : 'مؤقت النوم',
                      style: GoogleFonts.tajawal(
                        color: secondsRemaining != null ? const Color(0xFF168BD0) : Colors.white70,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(width: 8),
            ],
            title: Text('جاري التشغيل الآن', style: GoogleFonts.tajawal(color: Colors.white, fontSize: 16)),
          ),
          body: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),
              Center(
                child: Container(
                  width: 260,
                  height: 260,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: const Color(0xFF168BD0).withOpacity(0.3), blurRadius: 40, spreadRadius: 5)],
                  ),
                  child: ClipOval(
                    child: Image.asset('assets/images/sheikh_logo.jpg', fit: BoxFit.cover),
                  ),
                ),
              ).animate().scale(duration: 600.ms, curve: Curves.easeOut),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Text(
                  playback.title,
                  textAlign: TextAlign.center,
                  style: GoogleFonts.tajawal(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'فضيلة الشيخ محمد صديق المنشاوي',
                style: GoogleFonts.tajawal(fontSize: 15, color: Colors.grey[400]),
              ),
              const Spacer(),
              const AudioProgressBar(),
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.skip_previous_rounded, size: 45, color: Colors.white),
                      onPressed: playback.currentIndex > 0 ? _playPrevious : null,
                    ),
                    StreamBuilder<PlayerState>(
                      stream: globalAudioPlayer.playerStateStream,
                      builder: (context, snapshot) {
                        final playing = snapshot.data?.playing ?? false;
                        final processingState = snapshot.data?.processingState;
                        
                        return IconButton(
                          icon: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_fill),
                          iconSize: 85,
                          color: const Color(0xFF168BD0),
                          onPressed: () => playing ? globalAudioPlayer.pause() : globalAudioPlayer.play(),
                        );
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.skip_next_rounded, size: 45, color: Colors.white),
                      onPressed: playback.currentIndex < playback.playlist.length - 1 ? _playNext : null,
                    ),
                  ],
                ),
              ),
              const Spacer(),
            ],
          ),
        );
      },
    );
  }
}

// ==========================================
// 9. الودجت المخصصة لشريط تقدم التلاوة (Seek Bar)
// ==========================================
class AudioProgressBar extends StatelessWidget {
  const AudioProgressBar({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Duration>(
      stream: globalAudioPlayer.positionStream,
      builder: (context, snapshot) {
        final position = snapshot.data ?? Duration.zero;
        final duration = globalAudioPlayer.duration ?? Duration.zero;
        
        return Column(
          children: [
            SliderTheme(
              data: SliderTheme.of(context).copyWith(
                activeTrackColor: const Color(0xFF168BD0),
                inactiveTrackColor: Colors.grey[700],
                thumbColor: Colors.white,
                trackHeight: 4,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
              ),
              child: Slider(
                min: 0.0,
                max: duration.inMilliseconds.toDouble() > 0.0 ? duration.inMilliseconds.toDouble() : 1.0,
                value: position.inMilliseconds.toDouble().clamp(0.0, duration.inMilliseconds.toDouble() > 0.0 ? duration.inMilliseconds.toDouble() : 1.0),
                onChanged: (value) {
                  globalAudioPlayer.seek(Duration(milliseconds: value.toInt()));
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(_formatDuration(position), style: const TextStyle(color: Colors.grey, fontSize: 13)),
                  Text(_formatDuration(duration), style: const TextStyle(color: Colors.grey, fontSize: 13)),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  String _formatDuration(Duration d) {
    String minutes = d.inMinutes.toString().padLeft(2, '0');
    String seconds = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }
}

// ==========================================
// 10. شاشة "حسابي" الاحترافية بالكامل
// ==========================================
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  void _clearCache(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('archive_data_cache_v1');
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم تحديث قاعدة البيانات بنجاح، سيتم إعادة التحميل.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    User? user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          // كارت رأس الصفحة الفخم
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 10, offset: const Offset(0, 4))],
            ),
            child: Column(
              children: [
                const CircleAvatar(
                  radius: 40,
                  backgroundColor: Color(0xFF168BD0),
                  child: Icon(Icons.person_rounded, size: 40, color: Colors.white),
                ),
                const SizedBox(height: 12),
                Text(
                  user?.email ?? 'مستخدم مجهول',
                  style: GoogleFonts.tajawal(fontSize: 18, fontWeight: FontWeight.bold, color: const Color(0xFF1E293B)),
                ),
                const SizedBox(height: 24),
                
                // قسم الإحصائيات الحقيقية
                ValueListenableBuilder<List<String>>(
                  valueListenable: favoritesNotifier,
                  builder: (context, favs, child) {
                    return Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildStatItem('المفضلة', '${favs.length} تلاوة'),
                        Container(width: 1, height: 30, color: Colors.grey[200]),
                        _buildStatItem('العضوية', 'بريميوم'),
                      ],
                    );
                  },
                ),
              ],
            ),
          ).animate().fade().scale(duration: 400.ms),
          
          const SizedBox(height: 24),
          
          // الخيارات والتحكم بالحساب
          _buildItem(Icons.support_agent_rounded, 'تواصل مع الدعم الفني', () async {
            final uri = Uri(scheme: 'mailto', path: 'support@example.com', query: 'subject=تطبيق موسوعة الشيخ المنشاوي');
            if (await canLaunchUrl(uri)) await launchUrl(uri);
          }),
          _buildItem(Icons.cloud_sync_rounded, 'تحديث قاعدة البيانات (مسح الكاش)', () => _clearCache(context)),
          _buildItem(Icons.info_outline_rounded, 'حول التطبيق والإصدار', () {
            showAboutDialog(
              context: context,
              applicationName: 'موسوعة الشيخ المنشاوي',
              applicationVersion: '2.4.0',
              applicationIcon: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset('assets/images/app_logo.jpg', width: 50, height: 50),
              ),
            );
          }),
          _buildItem(Icons.logout_rounded, 'تسجيل خروج', () async {
            await FirebaseAuth.instance.signOut();
            globalAudioPlayer.stop();
            currentPlayback.value = null;
            if (context.mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
          }, isRed: true),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value) {
    return Column(
      children: [
        Text(value, style: GoogleFonts.tajawal(fontSize: 16, fontWeight: FontWeight.bold, color: const Color(0xFF168BD0))),
        const SizedBox(height: 4),
        Text(label, style: GoogleFonts.tajawal(fontSize: 12, color: Colors.grey)),
      ],
    );
  }

  Widget _buildItem(IconData icon, String title, VoidCallback onTap, {bool isRed = false}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.01), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: ListTile(
        onTap: onTap,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        leading: Icon(icon, color: isRed ? Colors.red : const Color(0xFF168BD0)),
        title: Text(title, style: GoogleFonts.tajawal(fontWeight: FontWeight.bold, color: isRed ? Colors.red : Colors.black, fontSize: 14)),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: Colors.grey),
      ),
    );
  }
}
